"""JOTACHI KARAOKE - servidor de IA.

Funciones:
  - /search        busca canciones en internet (yt-dlp)
  - /jobs          descarga + quita la voz (Demucs) + letra (LRCLIB o Whisper IA)
  - /jobs/upload   igual, pero con un archivo del teléfono
  - /mix           mezcla pista + voz grabada con eco/reverb (ffmpeg)
"""
import os
import re
import json
import sys
import time
import uuid
import shutil
import tempfile
import threading
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Optional

import requests
from fastapi import (BackgroundTasks, FastAPI, File, Form, HTTPException,
                     Request, UploadFile)
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel

VERSION = "2.0.0"
DATA = Path(os.environ.get("DATA_DIR", "/tmp/jotachi"))
(DATA / "jobs").mkdir(parents=True, exist_ok=True)
DEMUCS_MODEL = os.environ.get("DEMUCS_MODEL", "htdemucs")
WHISPER_MODEL = os.environ.get("WHISPER_MODEL", "small")
KEEP_HOURS = float(os.environ.get("KEEP_HOURS", "24"))
API_KEY = os.environ.get("API_KEY", "")

app = FastAPI(title="JOTACHI KARAOKE", version=VERSION)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"],
                   allow_headers=["*"])


@app.middleware("http")
async def check_key(request: Request, call_next):
    if API_KEY and request.url.path not in ("/", "/health"):
        if request.headers.get("x-api-key", "") != API_KEY:
            from fastapi.responses import JSONResponse
            return JSONResponse({"detail": "Clave API incorrecta"}, status_code=401)
    return await call_next(request)


JOBS: dict = {}
POOL = ThreadPoolExecutor(max_workers=1)  # tarea pesada: una canción a la vez
ID_RE = re.compile(r"^[a-f0-9]{12}$")


# ───────────────────────── utilidades ─────────────────────────
def job_dir(jid: str) -> Path:
    if not ID_RE.match(jid):
        raise HTTPException(400, "ID inválido")
    return DATA / "jobs" / jid


def new_job(title: str, artist: str, duration: Optional[int]):
    jid = uuid.uuid4().hex[:12]
    d = job_dir(jid)
    d.mkdir(parents=True)
    meta = {"title": title, "artist": artist, "duration": duration}
    (d / "meta.json").write_text(json.dumps(meta), encoding="utf-8")
    JOBS[jid] = {"id": jid, "state": "queued", "progress": 0.0,
                 "message": "En cola…", "lyrics_source": None, "error": None}
    return jid, d


def upd(jid: str, **kw):
    JOBS.setdefault(jid, {"id": jid}).update(kw)


def read_meta(d: Path) -> dict:
    try:
        return json.loads((d / "meta.json").read_text(encoding="utf-8"))
    except Exception:
        return {"title": "", "artist": "", "duration": None}


def cookie_opts() -> dict:
    c = os.environ.get("YT_COOKIES")
    if c:
        p = DATA / "cookies.txt"
        p.write_text(c)
        return {"cookiefile": str(p)}
    return {}


def clean(s: str) -> str:
    s = re.sub(r"[\(\[].*?[\)\]]", "", s or "")
    s = re.sub(r"(?i)\b(official|video|lyrics?|letra|audio|hd|4k|mv|karaoke|oficial|en vivo|live|vevo)\b", "", s)
    return re.sub(r"\s+", " ", s).strip(" -–|")


def guess(title: str, artist: str):
    artist = (artist or "").replace(" - Topic", "")
    if " - " in title:
        a, t = title.split(" - ", 1)
        return clean(t), clean(a)
    return clean(title), clean(artist)


def ts(sec: float) -> str:
    m = int(sec // 60)
    return f"[{m:02d}:{sec - m * 60:05.2f}]"


# ───────────────────────── letras ─────────────────────────
def lrclib(title: str, artist: str, duration: Optional[int]) -> Optional[str]:
    t, a = guess(title, artist)
    if not t:
        return None
    h = {"User-Agent": f"JOTACHI-KARAOKE/{VERSION}"}
    try:
        p = {"track_name": t, "artist_name": a}
        if duration:
            p["duration"] = int(duration)
        r = requests.get("https://lrclib.net/api/get", params=p, headers=h, timeout=15)
        if r.ok and r.json().get("syncedLyrics"):
            return r.json()["syncedLyrics"]
    except Exception:
        pass
    try:
        r = requests.get("https://lrclib.net/api/search",
                         params={"q": f"{a} {t}".strip()}, headers=h, timeout=15)
        if r.ok:
            items = [i for i in r.json() if i.get("syncedLyrics")]
            if duration:
                items = [i for i in items
                         if abs((i.get("duration") or 0) - duration) <= 15]
                items.sort(key=lambda i: abs((i.get("duration") or 0) - duration))
            if items:
                return items[0]["syncedLyrics"]
    except Exception:
        pass
    return None


_wm = None
_wlock = threading.Lock()


def whisper_lrc(path: Path, language: Optional[str]) -> Optional[str]:
    """La IA escucha la voz separada y copia la letra con sus tiempos."""
    global _wm
    from faster_whisper import WhisperModel
    with _wlock:
        if _wm is None:
            _wm = WhisperModel(WHISPER_MODEL, device="cpu", compute_type="int8",
                               cpu_threads=os.cpu_count() or 2)
    segs, _info = _wm.transcribe(str(path), language=language or None,
                                 vad_filter=True, beam_size=5,
                                 word_timestamps=True,
                                 condition_on_previous_text=False)
    lines, cur, start, last_end = [], [], None, 0.0
    for s in segs:
        for w in (s.words or []):
            txt = w.word.strip()
            if not txt:
                continue
            if cur and (w.start - last_end > 0.9 or len(cur) >= 8):
                lines.append((start, " ".join(cur)))
                cur, start = [], None
            if start is None:
                start = w.start
            cur.append(txt)
            last_end = w.end
    if cur:
        lines.append((start, " ".join(cur)))
    if not lines:
        return None
    return "\n".join(f"{ts(t)}{x}" for t, x in lines)


def make_lyrics(jid: str, d: Path, mode: str, language: Optional[str]):
    meta = read_meta(d)
    upd(jid, state="lyrics", progress=0.78, message="Buscando la letra…")
    lrc, src = None, None
    if mode != "ia":
        lrc = lrclib(meta["title"], meta["artist"], meta.get("duration"))
        src = "lrclib" if lrc else None
    vocals = d / "vocals.mp3"
    if not lrc and vocals.exists():
        upd(jid, progress=0.82, message="La IA está escuchando la voz…")
        lrc = whisper_lrc(vocals, language)
        src = "ia" if lrc else None
    f = d / "lyrics.lrc"
    if lrc:
        f.write_text(lrc, encoding="utf-8")
    elif f.exists():
        f.unlink()
    upd(jid, lyrics_source=src)


# ───────────────────────── proceso principal ─────────────────────────
def download_audio(jid: str, d: Path, video_id: Optional[str], query: str):
    import yt_dlp

    target = (f"https://www.youtube.com/watch?v={video_id}" if video_id
              else f"ytsearch1:{query}")

    def hook(h):
        if h.get("status") == "downloading":
            tot = h.get("total_bytes") or h.get("total_bytes_estimate") or 0
            if tot:
                upd(jid, progress=0.02 + 0.18 * h["downloaded_bytes"] / tot)

    opts = {
        "format": "bestaudio/best",
        "outtmpl": str(d / "original.%(ext)s"),
        "quiet": True, "noplaylist": True, "progress_hooks": [hook],
        "postprocessors": [{"key": "FFmpegExtractAudio",
                            "preferredcodec": "mp3", "preferredquality": "192"}],
        **cookie_opts(),
    }
    with yt_dlp.YoutubeDL(opts) as y:
        y.extract_info(target, download=True)
    if not (d / "original.mp3").exists():
        raise RuntimeError("No se pudo descargar el audio de esa canción")


def separate(jid: str, d: Path):
    out = d / "sep"
    cmd = [sys.executable, "-m", "demucs.separate", "-n", DEMUCS_MODEL,
           "--two-stems", "vocals", "--mp3", "--mp3-bitrate", "192",
           "-d", "cpu", "-o", str(out), str(d / "original.mp3")]
    proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
    buf = b""
    fd = proc.stderr.fileno()
    while True:
        chunk = os.read(fd, 1024)
        if not chunk:
            break
        buf = (buf + chunk)[-2000:]
        m = re.findall(rb"(\d{1,3})%", buf)
        if m:
            pct = min(int(m[-1]), 100)
            upd(jid, progress=0.2 + 0.55 * pct / 100,
                message=f"Quitando la voz con IA… {pct}%")
    if proc.wait() != 0:
        raise RuntimeError("Falló la separación de voz")
    stem = out / DEMUCS_MODEL / "original"
    shutil.move(str(stem / "no_vocals.mp3"), str(d / "no_vocals.mp3"))
    shutil.move(str(stem / "vocals.mp3"), str(d / "vocals.mp3"))
    shutil.rmtree(out, ignore_errors=True)


def run_job(jid: str, d: Path, o: dict):
    try:
        if o["source"] == "download":
            upd(jid, state="downloading", progress=0.02,
                message="Descargando la canción de internet…")
            download_audio(jid, d, o.get("video_id"), o.get("query", ""))
        if o.get("already_instrumental"):
            shutil.copy(d / "original.mp3", d / "no_vocals.mp3")
        else:
            upd(jid, state="separating", progress=0.2,
                message="Quitando la voz con IA…")
            separate(jid, d)
        make_lyrics(jid, d, o.get("lyrics_mode", "auto"), o.get("language"))
        upd(jid, state="done", progress=1.0, message="¡Listo!")
    except Exception as e:  # noqa
        upd(jid, state="error", error=str(e)[:300], message="Error")


def run_lyrics_only(jid: str, d: Path, mode: str, language: Optional[str]):
    try:
        make_lyrics(jid, d, mode, language)
        upd(jid, state="done", progress=1.0, message="¡Listo!")
    except Exception as e:  # noqa
        upd(jid, state="error", error=str(e)[:300], message="Error")


def cleaner():
    while True:
        time.sleep(3600)
        try:
            limit = time.time() - KEEP_HOURS * 3600
            for p in (DATA / "jobs").iterdir():
                if p.is_dir() and p.stat().st_mtime < limit:
                    shutil.rmtree(p, ignore_errors=True)
                    JOBS.pop(p.name, None)
        except Exception:
            pass


threading.Thread(target=cleaner, daemon=True).start()


# ───────────────────────── endpoints ─────────────────────────
@app.get("/")
def root():
    return {"app": "JOTACHI KARAOKE", "version": VERSION, "ok": True}


@app.get("/health")
def health():
    return {"ok": True, "version": VERSION}


@app.get("/search")
def search(q: str, n: int = 12):
    import yt_dlp
    opts = {"quiet": True, "skip_download": True, "extract_flat": True,
            **cookie_opts()}
    try:
        with yt_dlp.YoutubeDL(opts) as y:
            info = y.extract_info(f"ytsearch{min(n, 20)}:{q}", download=False)
    except Exception as e:
        raise HTTPException(502, f"Búsqueda falló: {str(e)[:200]}")
    res = []
    for e in info.get("entries") or []:
        if not e or not e.get("id"):
            continue
        res.append({
            "id": e["id"],
            "title": e.get("title") or "",
            "artist": (e.get("uploader") or e.get("channel") or "").replace(" - Topic", ""),
            "duration": int(e.get("duration") or 0),
            "thumb": f"https://i.ytimg.com/vi/{e['id']}/hqdefault.jpg",
        })
    return {"results": res}


class JobReq(BaseModel):
    video_id: Optional[str] = None
    query: Optional[str] = None
    title: str = ""
    artist: str = ""
    duration: Optional[int] = None
    lyrics_mode: str = "auto"
    language: Optional[str] = None


@app.post("/jobs")
def create_job(r: JobReq):
    if not (r.video_id or (r.query and r.query.strip())):
        raise HTTPException(400, "Falta video_id o query")
    jid, d = new_job(r.title, r.artist, r.duration)
    POOL.submit(run_job, jid, d, {
        "source": "download", "video_id": r.video_id, "query": r.query or "",
        "lyrics_mode": r.lyrics_mode, "language": r.language})
    return {"id": jid}


@app.post("/jobs/upload")
def create_upload(file: UploadFile = File(...), title: str = Form(""),
                  artist: str = Form(""), duration: int = Form(0),
                  already_instrumental: str = Form("false"),
                  lyrics_mode: str = Form("auto"),
                  language: Optional[str] = Form(None)):
    jid, d = new_job(title, artist, duration or None)
    src = d / ("upload" + (Path(file.filename or "a.mp3").suffix or ".mp3"))
    with open(src, "wb") as f:
        shutil.copyfileobj(file.file, f)
    p = subprocess.run(["ffmpeg", "-y", "-i", str(src), "-vn", "-ab", "192k",
                        str(d / "original.mp3")], capture_output=True)
    src.unlink(missing_ok=True)
    if p.returncode != 0:
        shutil.rmtree(d, ignore_errors=True)
        JOBS.pop(jid, None)
        raise HTTPException(400, "Audio no válido")
    POOL.submit(run_job, jid, d, {
        "source": "upload", "lyrics_mode": lyrics_mode, "language": language,
        "already_instrumental": already_instrumental.lower() == "true"})
    return {"id": jid}


@app.get("/jobs/{jid}")
def get_job(jid: str):
    d = job_dir(jid)
    if jid in JOBS:
        return JOBS[jid]
    if (d / "no_vocals.mp3").exists():
        return {"id": jid, "state": "done", "progress": 1.0, "message": "¡Listo!",
                "lyrics_source": None, "error": None}
    raise HTTPException(404, "Trabajo no encontrado")


@app.post("/jobs/{jid}/lyrics")
def relyrics(jid: str, mode: str = "ia", language: Optional[str] = None):
    d = job_dir(jid)
    if not (d / "no_vocals.mp3").exists():
        raise HTTPException(404, "La canción ya no está en el servidor")
    upd(jid, state="lyrics", progress=0.78, message="La IA está escuchando la voz…",
        error=None)
    POOL.submit(run_lyrics_only, jid, d, mode, language)
    return {"id": jid}


KINDS = {"original": "original.mp3", "instrumental": "no_vocals.mp3",
         "vocals": "vocals.mp3", "lrc": "lyrics.lrc"}


@app.get("/jobs/{jid}/file/{kind}")
def get_file(jid: str, kind: str):
    if kind not in KINDS:
        raise HTTPException(400, "Tipo inválido")
    f = job_dir(jid) / KINDS[kind]
    if not f.exists():
        raise HTTPException(404, "No disponible")
    return FileResponse(f, media_type="text/plain; charset=utf-8" if kind == "lrc"
                        else "audio/mpeg")


# ───────────────────────── mezcla con eco / reverb ─────────────────────────
def clamp(v, lo, hi):
    return max(lo, min(hi, v))


def voice_chain(echo: float, reverb: float, trim_ms: int, vol: float) -> str:
    f = []
    if trim_ms > 0:
        f.append(f"atrim=start={trim_ms / 1000:.3f},asetpts=PTS-STARTPTS")
    f += ["highpass=f=90", "lowpass=f=13000",
          "acompressor=threshold=0.125:ratio=3:attack=10:release=120:makeup=2",
          "equalizer=f=3000:t=q:w=1:g=2"]
    if reverb > 0.01:
        base = [0.42, 0.34, 0.26, 0.18, 0.10]
        decays = "|".join(f"{x * reverb:.3f}" for x in base)
        f.append(f"aecho=0.8:0.88:35|55|80|115|160:{decays}")
    if echo > 0.01:
        d1, d2 = int(240 + 200 * echo), int(480 + 300 * echo)
        f.append(f"aecho=0.85:0.9:{d1}|{d2}:{0.18 + 0.4 * echo:.2f}|{0.10 + 0.25 * echo:.2f}")
    f.append(f"volume={vol:.2f}")
    f.append("aformat=sample_rates=44100:channel_layouts=stereo")
    return ",".join(f)


@app.post("/mix")
def mix(bg: BackgroundTasks, music: UploadFile = File(...),
        voice: UploadFile = File(...), echo: float = Form(0.3),
        reverb: float = Form(0.3), music_vol: float = Form(1.0),
        voice_vol: float = Form(1.2), trim_ms: int = Form(120),
        speed: float = Form(1.0), pitch: float = Form(0.0)):
    tmp = Path(tempfile.mkdtemp(prefix="mix_", dir=DATA))
    mp, vp, out = tmp / "music.mp3", tmp / "voice.wav", tmp / "mix.mp3"
    with open(mp, "wb") as f:
        shutil.copyfileobj(music.file, f)
    with open(vp, "wb") as f:
        shutil.copyfileobj(voice.file, f)
    echo, reverb = clamp(echo, 0, 1), clamp(reverb, 0, 1)
    speed, pitch = clamp(speed, 0.5, 2.0), clamp(pitch, -12, 12)
    mf = []
    if abs(speed - 1) > 0.01 or abs(pitch) > 0.01:
        mf.append(f"rubberband=tempo={speed:.3f}:pitch={2 ** (pitch / 12):.5f}")
    mf.append(f"volume={clamp(music_vol, 0, 2):.2f}")
    mf.append("aformat=sample_rates=44100:channel_layouts=stereo")
    vf = voice_chain(echo, reverb, int(clamp(trim_ms, 0, 1000)),
                     clamp(voice_vol, 0, 3))
    fg = (f"[0:a]{','.join(mf)}[m];[1:a]{vf}[v];"
          f"[m][v]amix=inputs=2:duration=longest:normalize=0,alimiter=limit=0.95[o]")
    p = subprocess.run(["ffmpeg", "-y", "-i", str(mp), "-i", str(vp),
                        "-filter_complex", fg, "-map", "[o]", "-ac", "2",
                        "-b:a", "192k", str(out)],
                       capture_output=True, timeout=900)
    if p.returncode != 0:
        shutil.rmtree(tmp, ignore_errors=True)
        raise HTTPException(500, "ffmpeg: " + p.stderr.decode(errors="ignore")[-200:])
    bg.add_task(shutil.rmtree, tmp, True)
    return FileResponse(out, media_type="audio/mpeg", filename="mezcla.mp3")
