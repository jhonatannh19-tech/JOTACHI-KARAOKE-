---
title: Jotachi Karaoke
emoji: 🎤
colorFrom: purple
colorTo: blue
sdk: docker
app_port: 7860
pinned: true
---

Servidor de IA de JOTACHI KARAOKE (búsqueda, quitar voz, letras, mezcla).
