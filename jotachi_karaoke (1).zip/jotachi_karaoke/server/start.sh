#!/bin/bash
# yt-dlp se actualiza en cada arranque (YouTube cambia seguido)
pip install -q -U --user yt-dlp >/dev/null 2>&1 || true
exec uvicorn main:app --host 0.0.0.0 --port "${PORT:-7860}"
