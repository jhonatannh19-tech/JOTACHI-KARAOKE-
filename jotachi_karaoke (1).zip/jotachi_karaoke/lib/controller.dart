import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;

import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:just_audio/just_audio.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'api.dart';
import 'config.dart';
import 'models.dart';

class AppController extends ChangeNotifier {
  final AudioPlayer player = AudioPlayer();
  final AudioRecorder _rec = AudioRecorder();
  late SharedPreferences _prefs;
  bool _ready = false;
  Timer? _keepAlive;

  // Servidor
  String serverUrl = kDefaultServerUrl;
  String apiKey = '';
  Api api = Api(kDefaultServerUrl);
  bool serverOnline = false;
  bool serverChecking = false;

  // Biblioteca y búsqueda
  List<Track> library = [];
  Track? current;
  List<SongHit> results = [];
  bool searching = false;
  String? searchNote;

  // Procesamiento (descarga + quitar voz + letra)
  bool processing = false;
  double progress = 0;
  String statusMsg = '';
  String lyricsMode = 'auto'; // auto = letra de internet y si no, IA; ia = solo IA

  // Letras
  List<LrcLine> lyrics = [];
  int lyricIndex = -1;
  String? lyricsSource;

  // Controles
  bool voiceRemoved = true;
  double pitch = 0; // semitonos
  double speed = 1;
  double echo = 0.35;
  double reverb = 0.35;
  double musicVol = 1;
  double voiceVol = 1.2;
  double trimMs = 120;

  // Grabación
  bool recording = false;
  String? recordingPath;
  bool mixing = false;
  double _recSpeed = 1;
  double _recPitch = 0;

  // Mensajes para la pantalla
  String? toast;

  double get _pitchFactor => math.pow(2, pitch / 12).toDouble();

  void _toast(String m) {
    toast = m;
    notifyListeners();
  }

  // ───────────────────────── Inicio ─────────────────────────
  Future<void> init() async {
    if (_ready) return;
    _ready = true;
    _prefs = await SharedPreferences.getInstance();
    serverUrl = _prefs.getString('server') ?? kDefaultServerUrl;
    apiKey = _prefs.getString('apiKey') ?? '';
    api = Api(serverUrl, apiKey: apiKey);

    final raw = _prefs.getString('library');
    if (raw != null) {
      try {
        library = (jsonDecode(raw) as List)
            .map((e) => Track.fromJson(e as Map<String, dynamic>))
            .toList();
      } catch (_) {}
    }

    player.positionStream.listen(_onPosition);
    player.playerStateStream.listen((s) {
      if (s.processingState == ProcessingState.completed) {
        player.pause();
        player.seek(Duration.zero);
        if (recording) toggleRecord();
      }
      notifyListeners();
    });

    notifyListeners();
    await checkServer();
    // Mantiene el servidor despierto mientras la app está abierta.
    _keepAlive =
        Timer.periodic(const Duration(minutes: 4), (_) => checkServer());
  }

  Future<void> checkServer() async {
    serverChecking = true;
    notifyListeners();
    serverOnline = await api.health();
    serverChecking = false;
    notifyListeners();
  }

  Future<void> setServer(String url, String key) async {
    serverUrl = url.trim();
    apiKey = key.trim();
    await _prefs.setString('server', serverUrl);
    await _prefs.setString('apiKey', apiKey);
    api = Api(serverUrl, apiKey: apiKey);
    await checkServer();
  }

  Future<void> _saveLibrary() => _prefs.setString(
      'library', jsonEncode(library.map((t) => t.toJson()).toList()));

  Future<Directory> _trackDir(String id) async {
    final docs = await getApplicationDocumentsDirectory();
    final d = Directory('${docs.path}/tracks/$id');
    await d.create(recursive: true);
    return d;
  }

  // ───────────────────────── Búsqueda ─────────────────────────
  Future<void> search(String q) async {
    q = q.trim();
    if (q.isEmpty) return;
    searching = true;
    results = [];
    searchNote = null;
    notifyListeners();
    try {
      final r = await api.search(q);
      results = r.hits;
      searchNote = r.note;
      if (r.hits.isEmpty) searchNote = 'Sin resultados para "$q"';
    } catch (e) {
      searchNote = 'No se pudo buscar: $e';
    }
    searching = false;
    notifyListeners();
  }

  void clearResults() {
    results = [];
    searchNote = null;
    notifyListeners();
  }

  Future<void> singHit(SongHit h) async {
    if (processing) {
      _toast('Espera: ya se está procesando una canción');
      return;
    }
    Track? t;
    for (final x in library) {
      if (x.id == h.key) t = x;
    }
    if (t == null) {
      t = Track(
        id: h.key,
        title: h.title,
        artist: h.artist,
        thumb: h.thumb,
        durationSec: h.durationSec,
        videoId: h.videoId,
      );
      library.insert(0, t);
      await _saveLibrary();
    }
    results = [];
    searchNote = null;
    if (t.ready) {
      await selectTrack(t);
      _toast('Canción lista. Pulsa CANTAR AHORA');
    } else {
      await process(t);
    }
  }

  Future<Track?> pickFromPhone() async {
    final r = await FilePicker.platform.pickFiles(type: FileType.audio);
    if (r == null || r.files.single.path == null) return null;
    final src = r.files.single.path!;
    final name = p.basenameWithoutExtension(src);
    var artist = '';
    var title = name;
    if (name.contains(' - ')) {
      final i = name.indexOf(' - ');
      artist = name.substring(0, i).trim();
      title = name.substring(i + 3).trim();
    }
    final id = 'loc_${DateTime.now().millisecondsSinceEpoch}';
    final dir = await _trackDir(id);
    final dest = '${dir.path}/original${p.extension(src)}';
    await File(src).copy(dest);
    final t = Track(id: id, title: title, artist: artist, originalPath: dest);
    library.insert(0, t);
    await _saveLibrary();
    await selectTrack(t);
    return t;
  }

  // ───────────────────────── Procesar canción ─────────────────────────
  /// Descarga/sube la canción, quita la voz con IA y obtiene la letra.
  Future<void> process(Track t, {bool alreadyInstrumental = false}) async {
    if (processing) return;
    current = t;
    processing = true;
    progress = 0;
    statusMsg = 'Conectando con el servidor…';
    notifyListeners();
    try {
      final String jobId;
      if (t.originalPath != null) {
        jobId = await api.startUpload(File(t.originalPath!), t,
            alreadyInstrumental: alreadyInstrumental, lyricsMode: lyricsMode);
      } else {
        jobId = await api.startJob(t, lyricsMode: lyricsMode);
      }
      t.jobId = jobId;
      await _wait(jobId);
      statusMsg = 'Descargando pista sin voz…';
      notifyListeners();
      await _fetchFiles(t, jobId, withAudio: true);
      await _saveLibrary();
      await selectTrack(t);
      _toast(t.lrcPath != null
          ? '¡Listo! Voz quitada y letra lista. Pulsa CANTAR AHORA'
          : '¡Listo! Voz quitada (no se encontró letra)');
    } catch (e) {
      _toast('Error: $e');
    }
    processing = false;
    notifyListeners();
  }

  Future<void> _wait(String jobId) async {
    final sw = Stopwatch()..start();
    var fails = 0;
    while (true) {
      await Future.delayed(const Duration(seconds: 2));
      try {
        final st = await api.job(jobId);
        fails = 0;
        progress = st.progress;
        statusMsg = st.message;
        if (st.lyricsSource != null) lyricsSource = st.lyricsSource;
        notifyListeners();
        if (st.failed) throw Exception(st.error ?? 'Error del servidor');
        if (st.done) return;
      } on ApiException catch (e) {
        if (e.status == 404) rethrow;
        if (++fails > 6) rethrow;
      } on SocketException {
        if (++fails > 6) rethrow;
      } on TimeoutException {
        if (++fails > 6) rethrow;
      }
      if (sw.elapsed > const Duration(minutes: 35)) {
        throw Exception('Tiempo agotado');
      }
    }
  }

  Future<void> _fetchFiles(Track t, String jobId,
      {required bool withAudio}) async {
    final dir = await _trackDir(t.id);
    if (withAudio) {
      final inst = '${dir.path}/instrumental.mp3';
      await api.download(jobId, 'instrumental', inst);
      t.instrumentalPath = inst;
      if (t.originalPath == null) {
        final orig = '${dir.path}/original.mp3';
        await api.download(jobId, 'original', orig);
        t.originalPath = orig;
      }
    }
    final lrc = '${dir.path}/lyrics.lrc';
    try {
      await api.download(jobId, 'lrc', lrc);
      t.lrcPath = lrc;
      t.lyricsSource = lyricsSource;
    } on ApiException {
      t.lrcPath = null;
    }
  }

  /// Vuelve a pedir la letra a la IA (escucha la voz original y la transcribe).
  Future<void> regenerateLyrics() async {
    final t = current;
    if (t == null) {
      _toast('Primero elige una canción');
      return;
    }
    if (processing) return;
    if (!t.ready || t.jobId == null) {
      lyricsMode = 'ia';
      await process(t);
      return;
    }
    processing = true;
    progress = 0.78;
    statusMsg = 'La IA está escuchando la voz…';
    notifyListeners();
    try {
      await api.relyrics(t.jobId!, 'ia');
      await _wait(t.jobId!);
      await _fetchFiles(t, t.jobId!, withAudio: false);
      await _saveLibrary();
      await selectTrack(t);
      _toast(t.lrcPath != null
          ? 'Letra generada por IA'
          : 'La IA no encontró letra en esta canción');
    } on ApiException catch (e) {
      if (e.status == 404) {
        processing = false;
        t.instrumentalPath = null;
        lyricsMode = 'ia';
        await process(t);
        return;
      }
      _toast('Error: $e');
    } catch (e) {
      _toast('Error: $e');
    }
    processing = false;
    notifyListeners();
  }

  // ───────────────────────── Reproducción ─────────────────────────
  Future<void> selectTrack(Track t) async {
    current = t;
    lyrics = [];
    lyricIndex = -1;
    lyricsSource = t.lyricsSource;
    if (t.lrcPath != null && File(t.lrcPath!).existsSync()) {
      try {
        lyrics = parseLrc(await File(t.lrcPath!).readAsString());
      } catch (_) {}
    }
    notifyListeners();
    await _loadAudio();
  }

  Future<void> _loadAudio({bool keep = false}) async {
    final t = current;
    if (t == null) return;
    final String? path = (voiceRemoved && t.instrumentalPath != null)
        ? t.instrumentalPath
        : (t.originalPath ?? t.instrumentalPath);
    if (path == null || !File(path).existsSync()) return;
    final pos = keep ? player.position : Duration.zero;
    final was = keep && player.playing;
    try {
      await player.setFilePath(path);
      await player.setSpeed(speed);
      await player.setPitch(_pitchFactor);
      await player.setVolume(musicVol);
      if (pos > Duration.zero) await player.seek(pos);
      if (was) player.play();
    } catch (e) {
      _toast('No se pudo cargar el audio: $e');
    }
  }

  void _onPosition(Duration pos) {
    if (lyrics.isEmpty) return;
    final at = pos + const Duration(milliseconds: 150);
    var idx = -1;
    for (var i = 0; i < lyrics.length; i++) {
      if (lyrics[i].time <= at) {
        idx = i;
      } else {
        break;
      }
    }
    if (idx != lyricIndex) {
      lyricIndex = idx;
      notifyListeners();
    }
  }

  /// Botón grande: procesa si hace falta, si no reproduce/pausa.
  Future<void> singNow() async {
    final t = current;
    if (t == null) {
      _toast('Busca o importa una canción primero');
      return;
    }
    if (processing) return;
    if (voiceRemoved && t.instrumentalPath == null) {
      await process(t);
      return;
    }
    if (player.playing) {
      await player.pause();
    } else {
      player.play();
    }
  }

  Future<void> restart() async {
    await player.seek(Duration.zero);
  }

  Future<void> seek(Duration d) => player.seek(d);

  Future<void> toggleVoice() async {
    voiceRemoved = !voiceRemoved;
    notifyListeners();
    final t = current;
    if (t == null) return;
    if (voiceRemoved && t.instrumentalPath == null && !processing) {
      await process(t);
      return;
    }
    await _loadAudio(keep: true);
  }

  void setPitch(double v) {
    pitch = v;
    player.setPitch(_pitchFactor);
    notifyListeners();
  }

  void setSpeed(double v) {
    speed = v;
    player.setSpeed(v);
    notifyListeners();
  }

  void setMusicVol(double v) {
    musicVol = v;
    player.setVolume(v);
    notifyListeners();
  }

  void setEcho(double v) {
    echo = v;
    notifyListeners();
  }

  void setReverb(double v) {
    reverb = v;
    notifyListeners();
  }

  void setVoiceVol(double v) {
    voiceVol = v;
    notifyListeners();
  }

  void setTrim(double v) {
    trimMs = v;
    notifyListeners();
  }

  Future<void> deleteTrack(Track t) async {
    library.remove(t);
    await _saveLibrary();
    try {
      final dir = await _trackDir(t.id);
      if (await dir.exists()) await dir.delete(recursive: true);
    } catch (_) {}
    if (current == t) {
      await player.stop();
      current = null;
      lyrics = [];
      lyricIndex = -1;
    }
    notifyListeners();
  }

  // ───────────────────────── Grabación y mezcla ─────────────────────────
  Future<void> toggleRecord() async {
    if (recording) {
      final path = await _rec.stop();
      recording = false;
      if (path != null) recordingPath = path;
      await player.pause();
      _toast('Grabación lista. Ajusta eco/reverb y pulsa GUARDAR MEZCLA');
      return;
    }
    final t = current;
    if (t == null || t.instrumentalPath == null) {
      _toast('Primero quita la voz de una canción');
      return;
    }
    if (!await _rec.hasPermission()) {
      _toast('Permite el micrófono para grabar');
      return;
    }
    final docs = await getApplicationDocumentsDirectory();
    final path =
        '${docs.path}/rec_${DateTime.now().millisecondsSinceEpoch}.wav';
    voiceRemoved = true;
    await _loadAudio();
    await player.seek(Duration.zero);
    _recSpeed = speed;
    _recPitch = pitch;
    await _rec.start(
        const RecordConfig(
            encoder: AudioEncoder.wav, sampleRate: 44100, numChannels: 1),
        path: path);
    recording = true;
    recordingPath = path;
    player.play();
    notifyListeners();
    _toast('Grabando… usa audífonos para evitar eco del parlante');
  }

  /// Envía pista + voz al servidor, que aplica eco/reverb y devuelve el mp3 final.
  Future<String?> saveMix() async {
    final t = current;
    if (recordingPath == null || !File(recordingPath!).existsSync()) {
      _toast('Primero graba tu voz con el botón GRABAR');
      return null;
    }
    if (t == null || t.instrumentalPath == null) {
      _toast('Falta la pista sin voz');
      return null;
    }
    if (recording) await toggleRecord();
    mixing = true;
    notifyListeners();
    try {
      final docs = await getApplicationDocumentsDirectory();
      final out = Directory('${docs.path}/JOTACHI');
      await out.create(recursive: true);
      final safe = t.title.replaceAll(RegExp(r'[^\w\- ]'), '').trim();
      final dest =
          '${out.path}/${safe.isEmpty ? 'mezcla' : safe}_${DateTime.now().millisecondsSinceEpoch}.mp3';
      await api.mix(
        music: File(t.instrumentalPath!),
        voice: File(recordingPath!),
        dest: dest,
        echo: echo,
        reverb: reverb,
        musicVol: musicVol,
        voiceVol: voiceVol,
        trimMs: trimMs.round(),
        speed: _recSpeed,
        pitch: _recPitch,
      );
      mixing = false;
      notifyListeners();
      return dest;
    } catch (e) {
      mixing = false;
      _toast('No se pudo mezclar: $e');
      return null;
    }
  }

  @override
  void dispose() {
    _keepAlive?.cancel();
    player.dispose();
    _rec.dispose();
    super.dispose();
  }
}
