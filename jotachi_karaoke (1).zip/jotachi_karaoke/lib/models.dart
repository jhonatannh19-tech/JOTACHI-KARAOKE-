/// Resultado de búsqueda.
class SongHit {
  final String key; // yt_<id> o it_<id>
  final String? videoId;
  final String title;
  final String artist;
  final String thumb;
  final int durationSec;
  final String source;

  SongHit({
    required this.key,
    required this.videoId,
    required this.title,
    required this.artist,
    required this.thumb,
    required this.durationSec,
    required this.source,
  });
}

/// Canción de la biblioteca.
class Track {
  String id;
  String title;
  String artist;
  String thumb;
  int durationSec;
  String? videoId;
  String? jobId;
  String? originalPath;
  String? instrumentalPath;
  String? lrcPath;
  String? lyricsSource;

  Track({
    required this.id,
    required this.title,
    this.artist = '',
    this.thumb = '',
    this.durationSec = 0,
    this.videoId,
    this.jobId,
    this.originalPath,
    this.instrumentalPath,
    this.lrcPath,
    this.lyricsSource,
  });

  bool get ready => instrumentalPath != null;

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'artist': artist,
        'thumb': thumb,
        'durationSec': durationSec,
        'videoId': videoId,
        'jobId': jobId,
        'originalPath': originalPath,
        'instrumentalPath': instrumentalPath,
        'lrcPath': lrcPath,
        'lyricsSource': lyricsSource,
      };

  factory Track.fromJson(Map<String, dynamic> j) => Track(
        id: j['id'] as String,
        title: (j['title'] ?? '') as String,
        artist: (j['artist'] ?? '') as String,
        thumb: (j['thumb'] ?? '') as String,
        durationSec: (j['durationSec'] ?? 0) as int,
        videoId: j['videoId'] as String?,
        jobId: j['jobId'] as String?,
        originalPath: j['originalPath'] as String?,
        instrumentalPath: j['instrumentalPath'] as String?,
        lrcPath: j['lrcPath'] as String?,
        lyricsSource: j['lyricsSource'] as String?,
      );
}

class JobStatus {
  final String id;
  final String state;
  final double progress;
  final String message;
  final String? lyricsSource;
  final String? error;

  JobStatus({
    required this.id,
    required this.state,
    required this.progress,
    required this.message,
    this.lyricsSource,
    this.error,
  });

  bool get done => state == 'done';
  bool get failed => state == 'error';

  factory JobStatus.fromJson(Map<String, dynamic> j) => JobStatus(
        id: (j['id'] ?? '') as String,
        state: (j['state'] ?? '') as String,
        progress: ((j['progress'] ?? 0) as num).toDouble(),
        message: (j['message'] ?? '') as String,
        lyricsSource: j['lyrics_source'] as String?,
        error: j['error'] as String?,
      );
}

class LrcLine {
  final Duration time;
  final String text;
  LrcLine(this.time, this.text);
}

/// Lee un archivo .lrc (letras sincronizadas).
List<LrcLine> parseLrc(String s) {
  final out = <LrcLine>[];
  final tag = RegExp(r'\[(\d{1,3}):(\d{1,2})(?:[.:](\d{1,3}))?\]');
  for (final raw in s.split('\n')) {
    final line = raw.trim();
    if (line.isEmpty) continue;
    final ms = tag.allMatches(line).toList();
    if (ms.isEmpty) continue;
    final text = line.replaceAll(tag, '').trim();
    for (final m in ms) {
      final mm = int.parse(m.group(1)!);
      final ss = int.parse(m.group(2)!);
      final fr = m.group(3);
      var msec = 0;
      if (fr != null) {
        msec = int.parse(fr.padRight(3, '0').substring(0, 3));
      }
      out.add(LrcLine(
          Duration(minutes: mm, seconds: ss, milliseconds: msec), text));
    }
  }
  out.sort((a, b) => a.time.compareTo(b.time));
  return out;
}

String fmtDur(Duration d) {
  final m = d.inMinutes;
  final s = d.inSeconds % 60;
  return '$m:${s.toString().padLeft(2, '0')}';
}
