import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:path/path.dart' as p;
import 'package:share_plus/share_plus.dart';

import 'controller.dart';
import 'models.dart';
import 'theme.dart';

class HomeScreen extends StatefulWidget {
  final AppController c;
  const HomeScreen({super.key, required this.c});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _q = TextEditingController();
  AppController get c => widget.c;

  @override
  void initState() {
    super.initState();
    c.addListener(_onCtrl);
    c.init();
  }

  @override
  void dispose() {
    c.removeListener(_onCtrl);
    _q.dispose();
    super.dispose();
  }

  void _onCtrl() {
    final m = c.toast;
    if (m != null) {
      c.toast = null;
      if (!mounted) return;
      ScaffoldMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(SnackBar(content: Text(m)));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF1A0B3B), JC.bg, Color(0xFF05020B)],
          ),
        ),
        child: SafeArea(
          child: ListenableBuilder(
            listenable: c,
            builder: (context, _) => ListView(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 30),
              children: [
                _header(),
                const SizedBox(height: 14),
                _searchCard(),
                const SizedBox(height: 14),
                _nowCard(),
                const SizedBox(height: 14),
                _lyricsCard(),
                const SizedBox(height: 14),
                _functions(),
                const SizedBox(height: 14),
                _slidersCard(),
                const SizedBox(height: 14),
                _library(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ───────────────────────── Cabecera ─────────────────────────
  Widget _header() {
    final online = c.serverOnline;
    return Row(
      children: [
        Container(
          width: 46,
          height: 46,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            boxShadow: [BoxShadow(color: JC.purple.withAlpha(150), blurRadius: 18)],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(14),
            child: Image.asset(
              'assets/jotachi_logo.png',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(colors: [JC.purple, JC.blue]),
                ),
                child: const Icon(Icons.mic, color: JC.gold, size: 28),
              ),
            ),
          ),
        ),
        const SizedBox(width: 12),
        const Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('JOTACHI',
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 22,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 3)),
              Text('PROFESSIONAL KARAOKE',
                  style: TextStyle(
                      color: JC.gold,
                      fontSize: 10,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 2)),
            ],
          ),
        ),
        InkWell(
          borderRadius: BorderRadius.circular(20),
          onTap: _settings,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
            decoration: BoxDecoration(
              color: JC.card,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                  color: (online ? Colors.greenAccent : JC.red).withAlpha(160)),
            ),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              c.serverChecking
                  ? const SizedBox(
                      width: 10,
                      height: 10,
                      child: CircularProgressIndicator(strokeWidth: 2))
                  : Icon(Icons.circle,
                      size: 10, color: online ? Colors.greenAccent : JC.red),
              const SizedBox(width: 6),
              Text(online ? 'Servidor activo' : 'Sin servidor',
                  style: const TextStyle(fontSize: 11, color: Colors.white)),
              const SizedBox(width: 4),
              const Icon(Icons.settings, size: 15, color: JC.dim),
            ]),
          ),
        ),
      ],
    );
  }

  // ───────────────────────── Buscador ─────────────────────────
  Widget _searchCard() {
    return GlassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SectionTitle('BUSCAR CANCIÓN EN INTERNET', Icons.search),
          TextField(
            controller: _q,
            textInputAction: TextInputAction.search,
            onSubmitted: (v) => c.search(v),
            decoration: InputDecoration(
              hintText: 'Canción o artista…',
              hintStyle: const TextStyle(color: JC.dim),
              filled: true,
              fillColor: Colors.black38,
              prefixIcon: const Icon(Icons.search, color: JC.blue),
              suffixIcon: _q.text.isEmpty && c.results.isEmpty
                  ? null
                  : IconButton(
                      icon: const Icon(Icons.close, color: JC.dim),
                      onPressed: () {
                        _q.clear();
                        c.clearResults();
                      },
                    ),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: BorderSide.none,
              ),
            ),
          ),
          const SizedBox(height: 10),
          Row(children: [
            Expanded(
              child: NeonButton(
                label: 'BUSCAR',
                icon: Icons.travel_explore,
                onTap: c.searching ? null : () => c.search(_q.text),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: NeonButton(
                label: 'MI TELÉFONO',
                icon: Icons.folder_open,
                colors: const [Color(0xFF0A84FF), JC.blue],
                onTap: c.processing ? null : _import,
              ),
            ),
          ]),
          if (c.searching)
            const Padding(
              padding: EdgeInsets.only(top: 14),
              child: Center(child: CircularProgressIndicator()),
            ),
          if (c.searchNote != null)
            Padding(
              padding: const EdgeInsets.only(top: 10),
              child: Text(c.searchNote!,
                  style: const TextStyle(color: JC.dim, fontSize: 12)),
            ),
          for (final h in c.results.take(10)) _hitTile(h),
        ],
      ),
    );
  }

  Widget _cover(String url, double size) => ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: SizedBox(
          width: size,
          height: size,
          child: url.isEmpty
              ? _coverFallback()
              : Image.network(url,
                  fit: BoxFit.cover, errorBuilder: (_, __, ___) => _coverFallback()),
        ),
      );

  Widget _coverFallback() => Container(
        decoration: const BoxDecoration(
            gradient: LinearGradient(colors: [JC.purple, JC.blue])),
        child: const Icon(Icons.music_note, color: Colors.white70),
      );

  Widget _hitTile(SongHit h) => Padding(
        padding: const EdgeInsets.only(top: 10),
        child: Row(children: [
          _cover(h.thumb, 52),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(h.title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                        fontWeight: FontWeight.w700, fontSize: 13)),
                Text(
                    '${h.artist}${h.durationSec > 0 ? '  •  ${fmtDur(Duration(seconds: h.durationSec))}' : ''}',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: JC.dim, fontSize: 11)),
              ],
            ),
          ),
          const SizedBox(width: 8),
          SizedBox(
            width: 104,
            child: NeonButton(
              label: 'CANTAR',
              icon: Icons.mic,
              colors: const [JC.gold, Color(0xFFFF9500)],
              onTap: c.processing ? null : () => c.singHit(h),
            ),
          ),
        ]),
      );

  // ───────────────────────── Canción actual + reproductor ─────────────────────────
  Widget _nowCard() {
    final t = c.current;
    final playing = c.player.playing;
    final label = c.processing
        ? 'PROCESANDO…'
        : (t != null && c.voiceRemoved && !t.ready)
            ? 'QUITAR VOZ Y CANTAR'
            : playing
                ? 'PAUSAR'
                : 'CANTAR AHORA';
    final icon = c.processing
        ? Icons.hourglass_top
        : playing
            ? Icons.pause_circle
            : Icons.mic;
    return GlassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SectionTitle('AHORA', Icons.graphic_eq),
          Row(children: [
            _cover(t?.thumb ?? '', 70),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(t?.title ?? 'Ninguna canción elegida',
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          fontWeight: FontWeight.w800, fontSize: 16)),
                  const SizedBox(height: 3),
                  Text(t == null ? 'Busca o importa una canción' : t.artist,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(color: JC.dim, fontSize: 12)),
                  const SizedBox(height: 6),
                  Wrap(spacing: 6, children: [
                    if (t != null)
                      _chip(
                          c.voiceRemoved && t.ready
                              ? 'Sin voz'
                              : 'Voz original',
                          c.voiceRemoved && t.ready ? JC.gold : JC.blue),
                    if (c.lyrics.isNotEmpty)
                      _chip('Letra ${c.lyricsSource == 'ia' ? 'IA' : 'sincronizada'}',
                          JC.purple),
                  ]),
                ],
              ),
            ),
          ]),
          if (c.processing) ...[
            const SizedBox(height: 14),
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: LinearProgressIndicator(
                value: c.progress <= 0 ? null : c.progress.clamp(0.0, 1.0),
                minHeight: 8,
                color: JC.gold,
                backgroundColor: Colors.white12,
              ),
            ),
            const SizedBox(height: 6),
            Text(c.statusMsg,
                style: const TextStyle(color: JC.dim, fontSize: 12)),
          ],
          const SizedBox(height: 14),
          NeonButton(
            label: label,
            icon: icon,
            big: true,
            active: playing && !c.processing,
            colors: playing || c.processing
                ? null
                : const [JC.gold, Color(0xFFFF9500)],
            onTap: c.processing ? null : c.singNow,
          ),
          const SizedBox(height: 8),
          _seekBar(),
        ],
      ),
    );
  }

  Widget _chip(String text, Color col) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3),
        decoration: BoxDecoration(
          color: col.withAlpha(45),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: col.withAlpha(140)),
        ),
        child: Text(text,
            style: TextStyle(
                color: col == JC.purple ? Colors.white : col,
                fontSize: 10,
                fontWeight: FontWeight.w700)),
      );

  Widget _seekBar() {
    return StreamBuilder<Duration>(
      stream: c.player.positionStream,
      builder: (context, snap) {
        final pos = snap.data ?? Duration.zero;
        final dur = c.player.duration ?? Duration.zero;
        final max = dur.inMilliseconds.toDouble();
        final val = math.min(pos.inMilliseconds.toDouble(), max);
        return Row(children: [
          Text(fmtDur(pos),
              style: const TextStyle(color: JC.dim, fontSize: 11)),
          Expanded(
            child: Slider(
              value: max <= 0 ? 0 : val,
              min: 0,
              max: max <= 0 ? 1 : max,
              onChanged: max <= 0
                  ? null
                  : (v) => c.seek(Duration(milliseconds: v.round())),
            ),
          ),
          Text(fmtDur(dur),
              style: const TextStyle(color: JC.dim, fontSize: 11)),
        ]);
      },
    );
  }

  // ───────────────────────── Letra karaoke ─────────────────────────
  Widget _lyricsCard() {
    return GlassCard(
      padding: const EdgeInsets.fromLTRB(12, 16, 12, 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.only(left: 4),
            child: SectionTitle('LETRA KARAOKE', Icons.lyrics),
          ),
          SizedBox(height: 250, child: _LyricsView(c: c)),
        ],
      ),
    );
  }

  // ───────────────────────── Botones de funciones ─────────────────────────
  Widget _functions() {
    final t = c.current;
    return GlassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SectionTitle('FUNCIONES', Icons.bolt),
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            childAspectRatio: 2.9,
            children: [
              NeonButton(
                label: 'QUITAR VOZ',
                icon: c.voiceRemoved ? Icons.mic_off : Icons.mic,
                active: c.voiceRemoved,
                onTap: t == null || c.processing ? null : c.toggleVoice,
              ),
              NeonButton(
                label: 'LETRA IA',
                icon: Icons.auto_awesome,
                onTap: t == null || c.processing ? null : c.regenerateLyrics,
              ),
              NeonButton(
                label: c.recording ? 'DETENER' : 'GRABAR',
                icon: c.recording ? Icons.stop_circle : Icons.fiber_manual_record,
                colors: c.recording
                    ? const [JC.red, Color(0xFFFF7A00)]
                    : const [Color(0xFFFF3B6B), JC.purple],
                onTap: t == null || c.processing ? null : c.toggleRecord,
              ),
              NeonButton(
                label: c.mixing ? 'MEZCLANDO…' : 'GUARDAR MEZCLA',
                icon: Icons.save_alt,
                colors: const [Color(0xFF00C9A7), JC.blue],
                onTap: c.mixing || c.processing ? null : _saveMix,
              ),
              NeonButton(
                label: 'REINICIAR',
                icon: Icons.replay,
                onTap: t == null ? null : c.restart,
              ),
              NeonButton(
                label: 'SERVIDOR',
                icon: Icons.dns,
                colors: const [Color(0xFF5B2BE2), JC.purple],
                onTap: _settings,
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ───────────────────────── Controles de audio ─────────────────────────
  Widget _slidersCard() {
    return GlassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SectionTitle('TONO, EFECTOS Y MEZCLADOR', Icons.tune),
          _sliderRow('Tono', '${c.pitch > 0 ? '+' : ''}${c.pitch.round()}',
              c.pitch, -6, 6, 12, c.setPitch),
          _sliderRow('Velocidad', '${c.speed.toStringAsFixed(2)}x', c.speed,
              0.7, 1.3, 12, c.setSpeed),
          _sliderRow('Eco', '${(c.echo * 100).round()}%', c.echo, 0, 1, 20,
              c.setEcho),
          _sliderRow('Reverb', '${(c.reverb * 100).round()}%', c.reverb, 0, 1,
              20, c.setReverb),
          _sliderRow('Volumen música', '${(c.musicVol * 100).round()}%',
              c.musicVol, 0, 1, 20, c.setMusicVol),
          _sliderRow('Volumen mi voz', '${(c.voiceVol * 100).round()}%',
              c.voiceVol, 0, 2, 20, c.setVoiceVol),
          _sliderRow('Ajuste de retardo', '${c.trimMs.round()} ms', c.trimMs, 0,
              400, 40, c.setTrim),
          const Padding(
            padding: EdgeInsets.only(top: 6),
            child: Text(
              'Eco, reverb, volumen de voz y retardo se aplican con calidad de estudio al pulsar GUARDAR MEZCLA. Tono, velocidad y volumen de música suenan en vivo.',
              style: TextStyle(color: JC.dim, fontSize: 11),
            ),
          ),
        ],
      ),
    );
  }

  Widget _sliderRow(String label, String valueText, double value, double min,
      double max, int divisions, ValueChanged<double> onChanged) {
    return Row(children: [
      SizedBox(
        width: 112,
        child: Text(label,
            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
      ),
      Expanded(
        child: Slider(
          value: value.clamp(min, max),
          min: min,
          max: max,
          divisions: divisions,
          onChanged: onChanged,
        ),
      ),
      SizedBox(
        width: 54,
        child: Text(valueText,
            textAlign: TextAlign.right,
            style: const TextStyle(color: JC.gold, fontSize: 12)),
      ),
    ]);
  }

  // ───────────────────────── Biblioteca ─────────────────────────
  Widget _library() {
    return GlassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SectionTitle('MI BIBLIOTECA', Icons.library_music),
          if (c.library.isEmpty)
            const Text('Aquí aparecerán tus canciones procesadas.',
                style: TextStyle(color: JC.dim, fontSize: 12)),
          for (final t in c.library)
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: _cover(t.thumb, 46),
              title: Text(t.title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                      fontWeight: FontWeight.w700,
                      color: identical(t, c.current) ? JC.gold : Colors.white)),
              subtitle: Text(
                  '${t.artist.isEmpty ? '' : '${t.artist}  •  '}${t.ready ? 'Sin voz listo' : 'Sin procesar'}',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: JC.dim, fontSize: 11)),
              trailing: IconButton(
                icon: const Icon(Icons.delete_outline, color: JC.dim),
                onPressed: c.processing ? null : () => _confirmDelete(t),
              ),
              onTap: c.processing ? null : () => c.selectTrack(t),
            ),
        ],
      ),
    );
  }

  Future<void> _confirmDelete(Track t) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: JC.card,
        title: const Text('¿Eliminar canción?'),
        content: Text(t.title),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancelar')),
          TextButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Eliminar')),
        ],
      ),
    );
    if (ok == true) await c.deleteTrack(t);
  }

  // ───────────────────────── Acciones ─────────────────────────
  Future<void> _import() async {
    final t = await c.pickFromPhone();
    if (t == null || !mounted) return;
    final choice = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: JC.card,
      builder: (ctx) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Padding(
            padding: EdgeInsets.all(16),
            child: Text('¿Qué quieres hacer con esta canción?',
                style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
          ),
          ListTile(
            leading: const Icon(Icons.auto_fix_high, color: JC.gold),
            title: const Text('Quitar la voz con IA'),
            subtitle: const Text('Separa la voz, copia la letra y deja la pista'),
            onTap: () => Navigator.pop(ctx, 'remove'),
          ),
          ListTile(
            leading: const Icon(Icons.piano, color: JC.blue),
            title: const Text('Esta canción ya no tiene voz'),
            subtitle: const Text('Solo buscar su letra en internet'),
            onTap: () => Navigator.pop(ctx, 'instr'),
          ),
          ListTile(
            leading: const Icon(Icons.play_arrow, color: JC.dim),
            title: const Text('Solo reproducir'),
            onTap: () => Navigator.pop(ctx, 'none'),
          ),
        ]),
      ),
    );
    if (choice == 'remove') {
      await c.process(t);
    } else if (choice == 'instr') {
      await c.process(t, alreadyInstrumental: true);
    }
  }

  Future<void> _saveMix() async {
    final path = await c.saveMix();
    if (path == null || !mounted) return;
    await c.player.pause();
    if (!mounted) return;
    await showDialog<void>(
        context: context, builder: (_) => _MixDialog(path: path));
  }

  Future<void> _settings() async {
    final url = TextEditingController(text: c.serverUrl);
    final key = TextEditingController(text: c.apiKey);
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: JC.card,
        title: const Text('Servidor JOTACHI'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(
            controller: url,
            keyboardType: TextInputType.url,
            decoration: const InputDecoration(
                labelText: 'Dirección del servidor',
                hintText: 'https://usuario-jotachi.hf.space'),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: key,
            decoration: const InputDecoration(
                labelText: 'Clave API (opcional)'),
          ),
        ]),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx), child: const Text('Cerrar')),
          TextButton(
            onPressed: () async {
              Navigator.pop(ctx);
              await c.setServer(url.text, key.text);
              if (!mounted) return;
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                  content: Text(c.serverOnline
                      ? 'Servidor conectado ✔'
                      : 'No se pudo conectar. Si estaba dormido, espera 1 minuto y reintenta.')));
            },
            child: const Text('Guardar y probar'),
          ),
        ],
      ),
    );
  }
}

// ───────────────────────── Letras con auto-scroll ─────────────────────────
class _LyricsView extends StatefulWidget {
  final AppController c;
  const _LyricsView({required this.c});

  @override
  State<_LyricsView> createState() => _LyricsViewState();
}

class _LyricsViewState extends State<_LyricsView> {
  final _sc = ScrollController();
  static const double _h = 50;
  int _last = -2;

  @override
  void dispose() {
    _sc.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final c = widget.c;
    final lines = c.lyrics;
    if (lines.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Text(
            c.processing
                ? 'La IA está preparando la letra…'
                : 'La letra aparecerá aquí cuando quites la voz.\nTambién puedes pulsar LETRA IA.',
            textAlign: TextAlign.center,
            style: const TextStyle(color: JC.dim),
          ),
        ),
      );
    }
    if (c.lyricIndex != _last) {
      _last = c.lyricIndex;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!_sc.hasClients) return;
        final target = math.max(0.0, c.lyricIndex * _h - 2 * _h);
        _sc.animateTo(math.min(target, _sc.position.maxScrollExtent),
            duration: const Duration(milliseconds: 350),
            curve: Curves.easeOut);
      });
    }
    return ListView.builder(
      controller: _sc,
      itemExtent: _h,
      itemCount: lines.length,
      itemBuilder: (_, i) {
        final cur = i == c.lyricIndex;
        final past = i < c.lyricIndex;
        final text = lines[i].text.isEmpty ? '♪' : lines[i].text;
        return Center(
          child: FittedBox(
            fit: BoxFit.scaleDown,
            child: AnimatedDefaultTextStyle(
              duration: const Duration(milliseconds: 250),
              style: TextStyle(
                fontSize: cur ? 24 : 18,
                fontWeight: cur ? FontWeight.w900 : FontWeight.w500,
                color: cur ? JC.gold : (past ? Colors.white30 : Colors.white70),
                shadows: cur
                    ? [Shadow(color: JC.gold.withAlpha(160), blurRadius: 14)]
                    : null,
              ),
              child: Text(text, textAlign: TextAlign.center),
            ),
          ),
        );
      },
    );
  }
}

// ───────────────────────── Resultado de la mezcla ─────────────────────────
class _MixDialog extends StatefulWidget {
  final String path;
  const _MixDialog({required this.path});

  @override
  State<_MixDialog> createState() => _MixDialogState();
}

class _MixDialogState extends State<_MixDialog> {
  final AudioPlayer _p = AudioPlayer();

  @override
  void initState() {
    super.initState();
    _p.setFilePath(widget.path);
  }

  @override
  void dispose() {
    _p.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: JC.card,
      title: const Text('¡Mezcla guardada!'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        Text(p.basename(widget.path),
            maxLines: 2,
            textAlign: TextAlign.center,
            style: const TextStyle(color: JC.dim, fontSize: 12)),
        const SizedBox(height: 12),
        StreamBuilder<PlayerState>(
          stream: _p.playerStateStream,
          builder: (_, snap) {
            final playing = snap.data?.playing ?? false;
            return SizedBox(
              width: 200,
              child: NeonButton(
                label: playing ? 'PAUSAR' : 'ESCUCHAR',
                icon: playing ? Icons.pause : Icons.play_arrow,
                onTap: () => playing ? _p.pause() : _p.play(),
              ),
            );
          },
        ),
      ]),
      actions: [
        TextButton(
          onPressed: () => Share.shareXFiles([XFile(widget.path)],
              text: 'Mi canción con JOTACHI KARAOKE'),
          child: const Text('Compartir'),
        ),
        TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cerrar')),
      ],
    );
  }
}
