import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;

import 'models.dart';

class ApiException implements Exception {
  final int status;
  final String message;
  ApiException(this.status, this.message);
  @override
  String toString() => message;
}

class SearchResult {
  final List<SongHit> hits;
  final String? note;
  SearchResult(this.hits, this.note);
}

/// Cliente del servidor JOTACHI (búsqueda en internet, quitar voz, letras IA, mezcla).
class Api {
  final String base;
  final String apiKey;

  Api(String url, {this.apiKey = ''})
      : base = url.trim().replaceAll(RegExp(r'/+$'), '');

  Map<String, String> get _h => {
        if (apiKey.isNotEmpty) 'X-API-Key': apiKey,
      };

  Map<String, String> get _hJson => {
        ..._h,
        'Content-Type': 'application/json',
      };

  Uri _u(String path, [Map<String, String>? q]) {
    final u = Uri.parse('$base$path');
    return q == null ? u : u.replace(queryParameters: q);
  }

  String _err(http.Response r) {
    try {
      final j = jsonDecode(utf8.decode(r.bodyBytes));
      if (j is Map && j['detail'] != null) return j['detail'].toString();
    } catch (_) {}
    return 'Error del servidor (${r.statusCode})';
  }

  Future<bool> health() async {
    try {
      final r = await http
          .get(_u('/health'), headers: _h)
          .timeout(const Duration(seconds: 25));
      return r.statusCode == 200;
    } catch (_) {
      return false;
    }
  }

  /// Busca en internet con el servidor; si no responde usa el catálogo público de iTunes.
  Future<SearchResult> search(String q) async {
    try {
      final r = await http
          .get(_u('/search', {'q': q}), headers: _h)
          .timeout(const Duration(seconds: 45));
      if (r.statusCode == 200) {
        final j = jsonDecode(utf8.decode(r.bodyBytes)) as Map<String, dynamic>;
        final list = (j['results'] as List).cast<Map<String, dynamic>>();
        final hits = list
            .map((e) => SongHit(
                  key: 'yt_${e['id']}',
                  videoId: e['id'] as String,
                  title: (e['title'] ?? '') as String,
                  artist: (e['artist'] ?? '') as String,
                  thumb: (e['thumb'] ?? '') as String,
                  durationSec: ((e['duration'] ?? 0) as num).toInt(),
                  source: 'youtube',
                ))
            .toList();
        if (hits.isNotEmpty) return SearchResult(hits, null);
      }
    } catch (_) {}

    final r = await http
        .get(Uri.https('itunes.apple.com', '/search',
            {'term': q, 'entity': 'song', 'limit': '20'}))
        .timeout(const Duration(seconds: 20));
    if (r.statusCode != 200) {
      throw ApiException(r.statusCode, 'No se pudo buscar');
    }
    final j = jsonDecode(utf8.decode(r.bodyBytes)) as Map<String, dynamic>;
    final list = (j['results'] as List).cast<Map<String, dynamic>>();
    final hits = list
        .map((e) => SongHit(
              key: 'it_${e['trackId']}',
              videoId: null,
              title: (e['trackName'] ?? '') as String,
              artist: (e['artistName'] ?? '') as String,
              thumb: ((e['artworkUrl100'] ?? '') as String)
                  .replaceAll('100x100', '300x300'),
              durationSec: (((e['trackTimeMillis'] ?? 0) as num) / 1000).round(),
              source: 'itunes',
            ))
        .toList();
    return SearchResult(
        hits, 'Servidor sin respuesta: resultados del catálogo público.');
  }

  String _jobId(http.Response r) {
    if (r.statusCode != 200) throw ApiException(r.statusCode, _err(r));
    final j = jsonDecode(utf8.decode(r.bodyBytes)) as Map<String, dynamic>;
    return j['id'] as String;
  }

  Future<String> startJob(Track t,
      {required String lyricsMode, String? language}) async {
    final r = await http
        .post(
          _u('/jobs'),
          headers: _hJson,
          body: jsonEncode({
            'video_id': t.videoId,
            'query': '${t.artist} ${t.title}'.trim(),
            'title': t.title,
            'artist': t.artist,
            'duration': t.durationSec,
            'lyrics_mode': lyricsMode,
            'language': language,
          }),
        )
        .timeout(const Duration(seconds: 90));
    return _jobId(r);
  }

  Future<String> startUpload(File f, Track t,
      {required bool alreadyInstrumental,
      required String lyricsMode,
      String? language}) async {
    final req = http.MultipartRequest('POST', _u('/jobs/upload'));
    req.headers.addAll(_h);
    req.fields['title'] = t.title;
    req.fields['artist'] = t.artist;
    req.fields['already_instrumental'] = alreadyInstrumental ? 'true' : 'false';
    req.fields['lyrics_mode'] = lyricsMode;
    req.fields['duration'] = t.durationSec.toString();
    if (language != null) req.fields['language'] = language;
    req.files.add(await http.MultipartFile.fromPath('file', f.path));
    final resp = await http.Response.fromStream(
        await req.send().timeout(const Duration(minutes: 6)));
    return _jobId(resp);
  }

  Future<JobStatus> job(String id) async {
    final r = await http
        .get(_u('/jobs/$id'), headers: _h)
        .timeout(const Duration(seconds: 30));
    if (r.statusCode != 200) throw ApiException(r.statusCode, _err(r));
    return JobStatus.fromJson(
        jsonDecode(utf8.decode(r.bodyBytes)) as Map<String, dynamic>);
  }

  Future<void> relyrics(String id, String mode, {String? language}) async {
    final q = {'mode': mode, if (language != null) 'language': language};
    final r = await http
        .post(_u('/jobs/$id/lyrics', q), headers: _h)
        .timeout(const Duration(seconds: 60));
    if (r.statusCode != 200) throw ApiException(r.statusCode, _err(r));
  }

  Future<void> download(String jobId, String kind, String dest) async {
    final client = http.Client();
    try {
      final req = http.Request('GET', _u('/jobs/$jobId/file/$kind'));
      req.headers.addAll(_h);
      final resp = await client.send(req).timeout(const Duration(minutes: 3));
      if (resp.statusCode != 200) {
        throw ApiException(resp.statusCode, 'Archivo "$kind" no disponible');
      }
      final sink = File(dest).openWrite();
      await resp.stream.pipe(sink);
    } finally {
      client.close();
    }
  }

  /// Mezcla pista + voz grabada con eco/reverb de calidad en el servidor.
  Future<void> mix({
    required File music,
    required File voice,
    required String dest,
    required double echo,
    required double reverb,
    required double musicVol,
    required double voiceVol,
    required int trimMs,
    required double speed,
    required double pitch,
  }) async {
    final req = http.MultipartRequest('POST', _u('/mix'));
    req.headers.addAll(_h);
    req.fields.addAll({
      'echo': echo.toStringAsFixed(3),
      'reverb': reverb.toStringAsFixed(3),
      'music_vol': musicVol.toStringAsFixed(3),
      'voice_vol': voiceVol.toStringAsFixed(3),
      'trim_ms': trimMs.toString(),
      'speed': speed.toStringAsFixed(3),
      'pitch': pitch.toStringAsFixed(3),
    });
    req.files.add(await http.MultipartFile.fromPath('music', music.path));
    req.files.add(await http.MultipartFile.fromPath('voice', voice.path));
    final resp = await req.send().timeout(const Duration(minutes: 10));
    if (resp.statusCode != 200) {
      final body = await resp.stream.bytesToString();
      var msg = 'Error del servidor (${resp.statusCode})';
      try {
        msg = (jsonDecode(body) as Map)['detail'].toString();
      } catch (_) {}
      throw ApiException(resp.statusCode, msg);
    }
    final sink = File(dest).openWrite();
    await resp.stream.pipe(sink);
  }
}
