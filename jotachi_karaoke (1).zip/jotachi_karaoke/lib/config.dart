/// Cambia esta dirección por la de tu servidor (Hugging Face Space).
/// También se puede cambiar dentro de la app: botón ⚙ de la pantalla principal.
const String kDefaultServerUrl = 'https://tatan17-docker.hf.space';
const String kAppName = 'JOTACHI KARAOKE';
