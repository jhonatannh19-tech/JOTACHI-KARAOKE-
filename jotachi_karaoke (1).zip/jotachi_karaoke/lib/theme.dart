import 'package:flutter/material.dart';

class JC {
  static const bg = Color(0xFF07040F);
  static const card = Color(0xFF130B26);
  static const purple = Color(0xFF8A2BE2);
  static const blue = Color(0xFF00B7FF);
  static const gold = Color(0xFFFFC83D);
  static const red = Color(0xFFFF3B6B);
  static const dim = Color(0xFF9C93B8);

  static ThemeData theme() => ThemeData(
        brightness: Brightness.dark,
        useMaterial3: true,
        scaffoldBackgroundColor: bg,
        colorScheme: const ColorScheme.dark(
          primary: purple,
          secondary: blue,
          surface: card,
        ),
        sliderTheme: SliderThemeData(
          activeTrackColor: blue,
          inactiveTrackColor: Colors.white12,
          thumbColor: gold,
          overlayColor: gold.withAlpha(40),
          trackHeight: 4,
        ),
        snackBarTheme: const SnackBarThemeData(
          backgroundColor: card,
          contentTextStyle: TextStyle(color: Colors.white),
          behavior: SnackBarBehavior.floating,
        ),
      );
}

/// Botón con degradado y brillo neón.
class NeonButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final VoidCallback? onTap;
  final bool active;
  final bool big;
  final List<Color>? colors;

  const NeonButton({
    super.key,
    required this.label,
    required this.icon,
    required this.onTap,
    this.active = false,
    this.big = false,
    this.colors,
  });

  @override
  Widget build(BuildContext context) {
    final cols = colors ??
        (active
            ? const [JC.gold, Color(0xFFFF9500)]
            : const [JC.purple, JC.blue]);
    final dark = active || (colors != null && colors!.first == JC.gold);
    final fg = dark ? Colors.black : Colors.white;
    final r = BorderRadius.circular(big ? 24 : 16);
    return Opacity(
      opacity: onTap == null ? 0.45 : 1,
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: cols),
          borderRadius: r,
          boxShadow: [
            BoxShadow(
              color: cols.first.withAlpha(120),
              blurRadius: big ? 28 : 14,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            borderRadius: r,
            onTap: onTap,
            child: Padding(
              padding: EdgeInsets.symmetric(
                  vertical: big ? 18 : 13, horizontal: 10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(icon, color: fg, size: big ? 30 : 22),
                  const SizedBox(width: 8),
                  Flexible(
                    child: Text(
                      label,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: fg,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 0.6,
                        fontSize: big ? 19 : 13,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class GlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  const GlassCard(
      {super.key,
      required this.child,
      this.padding = const EdgeInsets.all(16)});

  @override
  Widget build(BuildContext context) => Container(
        width: double.infinity,
        padding: padding,
        decoration: BoxDecoration(
          color: JC.card.withAlpha(235),
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: JC.purple.withAlpha(110)),
          boxShadow: [
            BoxShadow(color: JC.purple.withAlpha(40), blurRadius: 20),
          ],
        ),
        child: child,
      );
}

class SectionTitle extends StatelessWidget {
  final String text;
  final IconData icon;
  const SectionTitle(this.text, this.icon, {super.key});

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: Row(children: [
          Icon(icon, color: JC.gold, size: 20),
          const SizedBox(width: 8),
          Text(text,
              style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1,
                  fontSize: 14)),
        ]),
      );
}
