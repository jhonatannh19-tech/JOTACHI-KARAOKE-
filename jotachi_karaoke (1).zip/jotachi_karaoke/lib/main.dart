import 'package:flutter/material.dart';

import 'config.dart';
import 'controller.dart';
import 'home_screen.dart';
import 'theme.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const JotachiApp());
}

class JotachiApp extends StatefulWidget {
  const JotachiApp({super.key});

  @override
  State<JotachiApp> createState() => _JotachiAppState();
}

class _JotachiAppState extends State<JotachiApp> {
  final AppController controller = AppController();

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: kAppName,
        debugShowCheckedModeBanner: false,
        theme: JC.theme(),
        home: HomeScreen(c: controller),
      );
}
