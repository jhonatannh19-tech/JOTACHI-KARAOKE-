# JOTACHI PROFESSIONAL KARAOKE v2.0

## Qué incluye
- Buscador que usa internet (canciones y artistas) + importar desde el teléfono.
- Quitar voz con IA (Demucs) y letra automática: primero la busca sincronizada en internet; si no existe, una IA (Whisper) escucha la voz original y la copia con sus tiempos.
- Eco y reverb de estudio (se aplican al guardar la mezcla), tono, velocidad, volúmenes y ajuste de retardo.
- Todas las funciones en la pantalla principal; botones neón nuevos.
- Servidor siempre activo: la app lo despierta/mantiene, y GitHub lo consulta cada 10 min.

## 1) Servidor (una sola vez)
1. En huggingface.co crea un **Space** → SDK **Docker** → público.
2. Sube el contenido de la carpeta `server/` (main.py, Dockerfile, requirements.txt, start.sh, README.md).
3. Espera a que compile (~10-15 min). Tu URL será `https://USUARIO-NOMBRE.hf.space`.
4. (Opcional) En Settings del Space → Variables: `API_KEY` (clave para que nadie más lo use) y `YT_COOKIES` (si YouTube bloquea las descargas).

## 2) App
1. Pon tu URL en `lib/config.dart` (o dentro de la app, botón del servidor).
2. Sube el zip/proyecto a GitHub; el workflow `build_apk.yml` genera el APK (Actions → Artifacts).
3. Opcional: copia tu logo a `assets/jotachi_logo.png`.

## 3) Mantener el servidor activo
- Repo → Settings → Secrets → Actions → `SERVER_URL` = tu URL. El workflow `keep_alive.yml` la consulta cada 10 min.
- Refuerzo gratis: UptimeRobot con un monitor HTTP a `TU_URL/health` cada 5 min.

## Notas
- Procesar una canción en CPU gratuita tarda ~2-5 min; queda guardada en el teléfono.
- Para grabar usa audífonos. Ajusta "retardo" si tu voz suena tarde.
- Usa solo música que tengas derecho a usar.
