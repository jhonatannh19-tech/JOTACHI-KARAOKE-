"""Ajusta el proyecto Android generado por `flutter create` (permisos, SDK, nombre)."""
import re
from pathlib import Path

app = Path("android/app")

# Manifest
mf = app / "src/main/AndroidManifest.xml"
s = mf.read_text(encoding="utf-8")
perms = [
    "android.permission.INTERNET",
    "android.permission.RECORD_AUDIO",
    "android.permission.MODIFY_AUDIO_SETTINGS",
    "android.permission.WAKE_LOCK",
]
add = "".join(f'    <uses-permission android:name="{p}"/>\n' for p in perms if p not in s)
s = s.replace("<application", add + "    <application", 1)
if "usesCleartextTraffic" not in s:
    s = s.replace("<application", '<application android:usesCleartextTraffic="true"', 1)
s = re.sub(r'android:label="[^"]*"', 'android:label="JOTACHI KARAOKE"', s, count=1)
mf.write_text(s, encoding="utf-8")

# Gradle: minSdk 23 y compileSdk 36
for name in ("build.gradle.kts", "build.gradle"):
    g = app / name
    if g.exists():
        t = g.read_text(encoding="utf-8")
        t = t.replace("flutter.minSdkVersion", "23").replace("flutter.compileSdkVersion", "36")
        g.write_text(t, encoding="utf-8")
print("Android parcheado")
