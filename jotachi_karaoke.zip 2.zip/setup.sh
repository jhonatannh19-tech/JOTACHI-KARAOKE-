#!/usr/bin/env bash
set -euo pipefail

# 1) Genera la carpeta android si no existe
if [ ! -d android ]; then
  flutter create --platforms=android --project-name jotachi_karaoke --org com.jotachi .
fi

# 2) Permisos y nombre de la app
python3 - <<'PY'
import re
p = 'android/app/src/main/AndroidManifest.xml'
s = open(p, encoding='utf-8').read()
perms = ['android.permission.INTERNET',
         'android.permission.RECORD_AUDIO',
         'android.permission.MODIFY_AUDIO_SETTINGS']
add = ''.join('    <uses-permission android:name="%s"/>\n' % x for x in perms if x not in s)
s = s.replace('<application', add + '    <application', 1)
s = re.sub(r'android:label="[^"]*"', 'android:label="JOTACHI KARAOKE"', s, count=1)
open(p, 'w', encoding='utf-8').write(s)
PY

# 3) minSdk 24 (necesario para grabar audio)
for f in android/app/build.gradle android/app/build.gradle.kts; do
  if [ -f "$f" ]; then
    sed -i -E 's/minSdk(Version)?( =|) *flutter\.minSdkVersion/minSdk\1\2 24/' "$f"
  fi
done

# 4) Dependencias
flutter pub get

# 5) Logo como icono y pantalla de inicio
test -f assets/jotachi_logo.png
mkdir -p android/app/src/main/res/drawable-nodpi android/app/src/main/res/drawable
cp assets/jotachi_logo.png android/app/src/main/res/drawable-nodpi/jotachi_logo.png
for d in mdpi hdpi xhdpi xxhdpi xxxhdpi; do
  mkdir -p "android/app/src/main/res/mipmap-$d"
  cp assets/jotachi_logo.png "android/app/src/main/res/mipmap-$d/ic_launcher.png"
done
cat > android/app/src/main/res/drawable/launch_background.xml <<'XML'
<?xml version="1.0" encoding="utf-8"?>
<layer-list xmlns:android="http://schemas.android.com/apk/res/android">
    <item android:drawable="#090b35" />
    <item>
        <bitmap android:gravity="center" android:src="@drawable/jotachi_logo" />
    </item>
</layer-list>
XML
echo "Proyecto JOTACHI KARAOKE listo."
