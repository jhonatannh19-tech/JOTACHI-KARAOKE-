import 'package:flutter/material.dart';

class JColors {
  static const bg = Color(0xFF05061A);
  static const panel = Color(0xFF12143A);
  static const purple = Color(0xFF8B3DFF);
  static const blue = Color(0xFF00B7FF);
  static const gold = Color(0xFFFFC21A);
}

ThemeData buildTheme() {
  final scheme = ColorScheme.fromSeed(
    seedColor: JColors.purple,
    brightness: Brightness.dark,
  ).copyWith(
    primary: JColors.purple,
    secondary: JColors.blue,
    tertiary: JColors.gold,
    surface: JColors.panel,
  );
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: JColors.bg,
    appBarTheme: const AppBarTheme(
      backgroundColor: JColors.bg,
      foregroundColor: Colors.white,
      elevation: 0,
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: JColors.panel,
      indicatorColor: JColors.purple.withAlpha(120),
    ),
    sliderTheme: const SliderThemeData(
      activeTrackColor: JColors.blue,
      thumbColor: JColors.gold,
    ),
  );
}
