import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Song {
  final String id;
  String title;
  String path;
  String? lrcPath;
  String? instrumentalPath;
  String? vocalsPath;
  Map<String, String> stems;

  Song({
    required this.id,
    required this.title,
    required this.path,
    this.lrcPath,
    this.instrumentalPath,
    this.vocalsPath,
    Map<String, String>? stems,
  }) : stems = stems ?? {};

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'path': path,
        'lrc': lrcPath,
        'inst': instrumentalPath,
        'vocals': vocalsPath,
        'stems': stems,
      };

  factory Song.fromJson(Map<String, dynamic> j) => Song(
        id: j['id'] as String,
        title: j['title'] as String,
        path: j['path'] as String,
        lrcPath: j['lrc'] as String?,
        instrumentalPath: j['inst'] as String?,
        vocalsPath: j['vocals'] as String?,
        stems: Map<String, String>.from((j['stems'] ?? {}) as Map),
      );
}

class Take {
  final String id;
  String title;
  String voicePath;
  String musicPath;
  double voiceVol;
  double musicVol;
  double speed;
  double semitones;
  DateTime createdAt;
  String? mixedPath;

  Take({
    required this.id,
    required this.title,
    required this.voicePath,
    required this.musicPath,
    this.voiceVol = 1,
    this.musicVol = 0.8,
    this.speed = 1,
    this.semitones = 0,
    required this.createdAt,
    this.mixedPath,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'voice': voicePath,
        'music': musicPath,
        'vv': voiceVol,
        'mv': musicVol,
        'speed': speed,
        'semi': semitones,
        'at': createdAt.toIso8601String(),
        'mixed': mixedPath,
      };

  factory Take.fromJson(Map<String, dynamic> j) => Take(
        id: j['id'] as String,
        title: j['title'] as String,
        voicePath: j['voice'] as String,
        musicPath: j['music'] as String,
        voiceVol: (j['vv'] as num).toDouble(),
        musicVol: (j['mv'] as num).toDouble(),
        speed: (j['speed'] as num).toDouble(),
        semitones: (j['semi'] as num).toDouble(),
        createdAt: DateTime.parse(j['at'] as String),
        mixedPath: j['mixed'] as String?,
      );
}

class Library extends ChangeNotifier {
  Library._();
  static final Library I = Library._();

  final List<Song> songs = [];
  final List<Take> takes = [];
  late Directory root;

  Future<void> load() async {
    root = await getApplicationDocumentsDirectory();
    final p = await SharedPreferences.getInstance();
    try {
      final s = p.getString('songs');
      if (s != null) {
        for (final e in jsonDecode(s) as List) {
          songs.add(Song.fromJson(Map<String, dynamic>.from(e as Map)));
        }
      }
      final t = p.getString('takes');
      if (t != null) {
        for (final e in jsonDecode(t) as List) {
          takes.add(Take.fromJson(Map<String, dynamic>.from(e as Map)));
        }
      }
    } catch (_) {
      // datos antiguos o dañados: se empieza limpio
    }
  }

  Future<String> folder(String sub) async {
    final d = Directory('${root.path}/$sub');
    if (!await d.exists()) await d.create(recursive: true);
    return d.path;
  }

  Future<void> update() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('songs', jsonEncode(songs.map((e) => e.toJson()).toList()));
    await p.setString('takes', jsonEncode(takes.map((e) => e.toJson()).toList()));
    notifyListeners();
  }

  static String _ext(String path) {
    final i = path.lastIndexOf('.');
    return i < 0 ? '' : path.substring(i);
  }

  static String _stripExt(String name) {
    final i = name.lastIndexOf('.');
    return i <= 0 ? name : name.substring(0, i);
  }

  Future<Song> addSong(String sourcePath, String fileName) async {
    final id = DateTime.now().microsecondsSinceEpoch.toString();
    final dir = await folder('songs');
    final ext = _ext(sourcePath).isEmpty ? '.mp3' : _ext(sourcePath);
    final dest = '$dir/$id$ext';
    await File(sourcePath).copy(dest);
    final s = Song(id: id, title: _stripExt(fileName), path: dest);
    songs.insert(0, s);
    await update();
    return s;
  }

  Future<void> setLyrics(Song s, String sourcePath) async {
    final dir = await folder('lyrics');
    final dest = '$dir/${s.id}.lrc';
    await File(sourcePath).copy(dest);
    s.lrcPath = dest;
    await update();
  }

  Future<void> removeSong(Song s) async {
    final paths = <String?>[
      s.path,
      s.lrcPath,
      s.instrumentalPath,
      s.vocalsPath,
      ...s.stems.values,
    ];
    for (final p in paths) {
      if (p == null) continue;
      try {
        final f = File(p);
        if (await f.exists()) await f.delete();
      } catch (_) {}
    }
    songs.remove(s);
    await update();
  }

  Future<void> addTake(Take t) async {
    takes.insert(0, t);
    await update();
  }

  Future<void> removeTake(Take t) async {
    for (final p in [t.voicePath, t.mixedPath]) {
      if (p == null) continue;
      try {
        final f = File(p);
        if (await f.exists()) await f.delete();
      } catch (_) {}
    }
    takes.remove(t);
    await update();
  }
}
