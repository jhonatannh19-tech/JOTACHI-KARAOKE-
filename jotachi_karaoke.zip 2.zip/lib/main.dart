import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'actions.dart';
import 'api.dart';
import 'models.dart';
import 'player_screen.dart';
import 'takes_screen.dart';
import 'theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Library.I.load();
  runApp(const JotachiApp());
}

class JotachiApp extends StatelessWidget {
  const JotachiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'JOTACHI KARAOKE',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(),
      home: const Shell(),
    );
  }
}

class Shell extends StatefulWidget {
  const Shell({super.key});

  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int index = 0;

  @override
  Widget build(BuildContext context) {
    const pages = <Widget>[SongsTab(), TakesTab(), SettingsTab()];
    return Scaffold(
      body: IndexedStack(index: index, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (i) => setState(() => index = i),
        destinations: const [
          NavigationDestination(
              icon: Icon(Icons.library_music), label: 'Canciones'),
          NavigationDestination(
              icon: Icon(Icons.mic_external_on), label: 'Grabaciones'),
          NavigationDestination(icon: Icon(Icons.settings), label: 'Ajustes'),
        ],
      ),
    );
  }
}

Widget logoHeader() {
  return Padding(
    padding: const EdgeInsets.fromLTRB(16, 24, 16, 12),
    child: Center(
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(32),
          border: Border.all(color: JColors.gold, width: 2),
          boxShadow: const [
            BoxShadow(color: JColors.purple, blurRadius: 28, spreadRadius: 1),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(30),
          child: Image.asset('assets/jotachi_logo.png', height: 180),
        ),
      ),
    ),
  );
}

class SongsTab extends StatelessWidget {
  const SongsTab({super.key});

  Future<void> _import(BuildContext context) async {
    final r = await FilePicker.platform
        .pickFiles(type: FileType.audio, allowMultiple: true);
    if (r == null) return;
    for (final f in r.files) {
      if (f.path == null) continue;
      await Library.I.addSong(f.path!, f.name);
    }
  }

  Future<void> _attachLyrics(BuildContext context, Song s) async {
    final r = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['lrc', 'txt'],
    );
    if (r == null || r.files.single.path == null) return;
    await Library.I.setLyrics(s, r.files.single.path!);
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Letra sincronizada agregada.')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _import(context),
        icon: const Icon(Icons.add),
        label: const Text('Importar canción'),
        backgroundColor: JColors.gold,
        foregroundColor: Colors.black,
      ),
      body: SafeArea(
        child: ListenableBuilder(
          listenable: Library.I,
          builder: (context, _) {
            final songs = Library.I.songs;
            return ListView.builder(
              padding: const EdgeInsets.only(bottom: 100),
              itemCount: songs.length + 1,
              itemBuilder: (context, i) {
                if (i == 0) {
                  return Column(
                    children: [
                      logoHeader(),
                      if (songs.isEmpty)
                        const Padding(
                          padding: EdgeInsets.all(24),
                          child: Text(
                            'Toca "Importar canción" para agregar tu primera pista.',
                            textAlign: TextAlign.center,
                          ),
                        ),
                    ],
                  );
                }
                final s = songs[i - 1];
                return ListTile(
                  leading: const Icon(Icons.music_note, color: JColors.gold),
                  title: Text(s.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                  subtitle: Text([
                    if (s.instrumentalPath != null) 'Sin voz (IA)',
                    if (s.lrcPath != null) 'Letra',
                  ].join(' · ')),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => PlayerScreen(song: s)),
                  ),
                  trailing: PopupMenuButton<String>(
                    onSelected: (v) async {
                      if (v == 'lrc') {
                        await _attachLyrics(context, s);
                      } else if (v == 'sep') {
                        await separateWithDialog(context, s);
                      } else if (v == 'del') {
                        await Library.I.removeSong(s);
                      }
                    },
                    itemBuilder: (_) => const [
                      PopupMenuItem(value: 'lrc', child: Text('Agregar letra (.lrc)')),
                      PopupMenuItem(value: 'sep', child: Text('Separar voz con IA')),
                      PopupMenuItem(value: 'del', child: Text('Eliminar')),
                    ],
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}

class SettingsTab extends StatefulWidget {
  const SettingsTab({super.key});

  @override
  State<SettingsTab> createState() => _SettingsTabState();
}

class _SettingsTabState extends State<SettingsTab> {
  final ctrl = TextEditingController();
  String info = '';

  @override
  void initState() {
    super.initState();
    Api.baseUrl().then((u) {
      if (mounted) ctrl.text = u;
    });
  }

  @override
  void dispose() {
    ctrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    await Api.setBaseUrl(ctrl.text);
    setState(() => info = 'Dirección guardada.');
  }

  Future<void> _test() async {
    await Api.setBaseUrl(ctrl.text);
    setState(() => info = 'Probando conexión...');
    try {
      final ok = await Api.health();
      setState(() => info = ok
          ? 'Conectado. El servidor de IA responde.'
          : 'No hay respuesta. Revisa la dirección.');
    } catch (e) {
      setState(() => info = 'No se pudo conectar: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Ajustes')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Servidor de IA',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const Text(
            'Sirve para separar la voz de la música y para exportar la mezcla '
            'final. Pega aquí la dirección que te da el servidor (https://...).',
          ),
          const SizedBox(height: 12),
          TextField(
            controller: ctrl,
            keyboardType: TextInputType.url,
            decoration: const InputDecoration(
              border: OutlineInputBorder(),
              labelText: 'Dirección del servidor',
              hintText: 'https://mi-servidor.trycloudflare.com',
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              FilledButton(onPressed: _save, child: const Text('Guardar')),
              const SizedBox(width: 12),
              OutlinedButton(onPressed: _test, child: const Text('Probar conexión')),
            ],
          ),
          const SizedBox(height: 12),
          Text(info),
          const SizedBox(height: 24),
          const Text(
            'Consejo: canta con audífonos para que el micrófono no capte la música.',
          ),
        ],
      ),
    );
  }
}
