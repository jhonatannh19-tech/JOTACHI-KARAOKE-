import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'models.dart';

/// Comunicación con el servidor de IA (separación de voz y mezcla final).
class Api {
  static const Map<String, String> _h = {'ngrok-skip-browser-warning': 'true'};

  static Future<String> baseUrl() async {
    final p = await SharedPreferences.getInstance();
    var u = (p.getString('server_url') ?? '').trim();
    while (u.endsWith('/')) {
      u = u.substring(0, u.length - 1);
    }
    return u;
  }

  static Future<void> setBaseUrl(String u) async {
    final p = await SharedPreferences.getInstance();
    await p.setString('server_url', u.trim());
  }

  static Future<bool> health() async {
    final b = await baseUrl();
    if (b.isEmpty) return false;
    final r = await http
        .get(Uri.parse('$b/health'), headers: _h)
        .timeout(const Duration(seconds: 20));
    return r.statusCode == 200;
  }

  static Future<String> _needUrl() async {
    final b = await baseUrl();
    if (b.isEmpty) {
      throw Exception('Primero escribe la dirección del servidor en Ajustes.');
    }
    return b;
  }

  /// Separa voz e instrumental (y batería, bajo, otros si el servidor puede).
  static Future<void> separate(Song song, void Function(String) status) async {
    final b = await _needUrl();
    status('Subiendo la canción...');
    final req = http.MultipartRequest('POST', Uri.parse('$b/separate'));
    req.headers.addAll(_h);
    req.files.add(await http.MultipartFile.fromPath('file', song.path));
    final res = await http.Response.fromStream(
        await req.send().timeout(const Duration(minutes: 10)));
    if (res.statusCode != 200) {
      throw Exception('El servidor respondió ${res.statusCode}');
    }
    final job = (jsonDecode(res.body) as Map)['job'] as String;

    while (true) {
      await Future.delayed(const Duration(seconds: 4));
      final s = await http
          .get(Uri.parse('$b/status/$job'), headers: _h)
          .timeout(const Duration(seconds: 30));
      final j = jsonDecode(s.body) as Map<String, dynamic>;
      status((j['message'] ?? 'Procesando con IA...').toString());
      if (j['state'] == 'error') {
        throw Exception((j['message'] ?? 'Error en el servidor').toString());
      }
      if (j['state'] == 'done') break;
    }

    final dir = await Library.I.folder('stems');
    for (final name in ['vocals', 'instrumental', 'drums', 'bass', 'other']) {
      status('Descargando $name...');
      final r = await http.get(Uri.parse('$b/stem/$job/$name'), headers: _h);
      if (r.statusCode != 200) continue;
      final path = '$dir/${song.id}_$name.mp3';
      await File(path).writeAsBytes(r.bodyBytes);
      if (name == 'instrumental') {
        song.instrumentalPath = path;
      } else if (name == 'vocals') {
        song.vocalsPath = path;
      } else {
        song.stems[name] = path;
      }
    }
    await Library.I.update();
  }

  /// Mezcla voz + música en un solo MP3 usando el servidor.
  static Future<String> mix(Take t) async {
    final b = await _needUrl();
    final req = http.MultipartRequest('POST', Uri.parse('$b/mix'));
    req.headers.addAll(_h);
    req.fields['voice_vol'] = t.voiceVol.toString();
    req.fields['music_vol'] = t.musicVol.toString();
    req.fields['speed'] = t.speed.toString();
    req.fields['semitones'] = t.semitones.toString();
    req.files.add(await http.MultipartFile.fromPath('voice', t.voicePath));
    req.files.add(await http.MultipartFile.fromPath('music', t.musicPath));
    final res = await http.Response.fromStream(
        await req.send().timeout(const Duration(minutes: 5)));
    if (res.statusCode != 200) {
      throw Exception('El servidor respondió ${res.statusCode}');
    }
    final dir = await Library.I.folder('mixes');
    final path = '$dir/${t.id}.mp3';
    await File(path).writeAsBytes(res.bodyBytes);
    t.mixedPath = path;
    await Library.I.update();
    return path;
  }
}
