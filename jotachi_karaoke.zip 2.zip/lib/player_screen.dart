import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import 'actions.dart';
import 'lrc.dart';
import 'models.dart';
import 'studio_screen.dart';
import 'theme.dart';

class PlayerScreen extends StatefulWidget {
  final Song song;
  const PlayerScreen({super.key, required this.song});

  @override
  State<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends State<PlayerScreen> {
  final player = AudioPlayer();
  final recorder = AudioRecorder();
  final scroll = ScrollController();
  static const double lineH = 52;

  List<LrcLine> lyrics = [];
  bool useInstrumental = false;
  bool recording = false;
  bool playing = false;
  double speed = 1;
  double semis = 0;
  double volume = 1;
  Duration pos = Duration.zero;
  Duration dur = Duration.zero;
  int lineIdx = -1;
  final List<StreamSubscription<dynamic>> subs = [];

  String get currentPath =>
      (useInstrumental && widget.song.instrumentalPath != null)
          ? widget.song.instrumentalPath!
          : widget.song.path;

  @override
  void initState() {
    super.initState();
    useInstrumental = widget.song.instrumentalPath != null;
    _init();
  }

  Future<void> _init() async {
    lyrics = await loadLrc(widget.song.lrcPath);
    try {
      await player.setFilePath(currentPath);
    } catch (e) {
      _msg('No se pudo abrir la canción: $e');
    }
    subs.add(player.positionStream.listen((p) {
      if (!mounted) return;
      setState(() => pos = p);
      _follow();
    }));
    subs.add(player.durationStream.listen((d) {
      if (!mounted) return;
      setState(() => dur = d ?? Duration.zero);
    }));
    subs.add(player.playerStateStream.listen((st) async {
      if (!mounted) return;
      setState(() => playing = st.playing);
      if (st.processingState == ProcessingState.completed) {
        if (recording) {
          await _stopRecording();
        } else {
          await player.pause();
          await player.seek(Duration.zero);
        }
      }
    }));
    if (mounted) setState(() {});
  }

  void _msg(String t) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t)));
  }

  void _follow() {
    if (lyrics.isEmpty) return;
    var idx = -1;
    for (var i = 0; i < lyrics.length; i++) {
      if (lyrics[i].time <= pos) {
        idx = i;
      } else {
        break;
      }
    }
    if (idx != lineIdx) {
      lineIdx = idx;
      if (idx >= 0 && scroll.hasClients) {
        final target = (idx * lineH - scroll.position.viewportDimension / 2 + lineH / 2)
            .clamp(0.0, scroll.position.maxScrollExtent)
            .toDouble();
        scroll.animateTo(target,
            duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
      }
    }
  }

  Future<void> _applyTone() async {
    await player.setSpeed(speed);
    await player.setPitch(math.pow(2, semis / 12).toDouble());
  }

  Future<void> _switchSource(bool instrumental) async {
    final wasPlaying = player.playing;
    final p = player.position;
    setState(() => useInstrumental = instrumental);
    await player.setFilePath(currentPath);
    await player.seek(p);
    await _applyTone();
    await player.setVolume(volume);
    if (wasPlaying) unawaited(player.play());
  }

  Future<void> _startRecording() async {
    if (!await recorder.hasPermission()) {
      _msg('Necesito permiso para usar el micrófono.');
      return;
    }
    final dir = await getTemporaryDirectory();
    final path = '${dir.path}/take_${DateTime.now().millisecondsSinceEpoch}.wav';
    await recorder.start(
      const RecordConfig(
        encoder: AudioEncoder.wav,
        sampleRate: 44100,
        numChannels: 1,
        autoGain: false,
        echoCancel: false,
        noiseSuppress: false,
      ),
      path: path,
    );
    await player.seek(Duration.zero);
    unawaited(player.play());
    if (mounted) setState(() => recording = true);
  }

  Future<void> _stopRecording() async {
    if (!recording) return;
    recording = false;
    await player.pause();
    final path = await recorder.stop();
    if (!mounted) return;
    setState(() {});
    if (path == null) {
      _msg('No se pudo guardar la grabación.');
      return;
    }
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => StudioScreen(
          song: widget.song,
          rawPath: path,
          musicPath: currentPath,
          speed: speed,
          semitones: semis,
        ),
      ),
    );
  }

  @override
  void dispose() {
    for (final s in subs) {
      s.cancel();
    }
    player.dispose();
    recorder.dispose();
    scroll.dispose();
    super.dispose();
  }

  String _fmt(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    final maxMs = math.max(dur.inMilliseconds, 1).toDouble();
    final posMs = math.min(pos.inMilliseconds.toDouble(), maxMs);
    final hasInst = widget.song.instrumentalPath != null;

    return Scaffold(
      appBar: AppBar(title: Text(widget.song.title, overflow: TextOverflow.ellipsis)),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: lyrics.isEmpty
                  ? const Center(
                      child: Padding(
                        padding: EdgeInsets.all(24),
                        child: Text(
                          'Esta canción no tiene letra sincronizada.\n'
                          'Agrégala desde el menú de la canción (.lrc).',
                          textAlign: TextAlign.center,
                        ),
                      ),
                    )
                  : ListView.builder(
                      controller: scroll,
                      itemExtent: lineH,
                      itemCount: lyrics.length,
                      itemBuilder: (_, i) {
                        final active = i == lineIdx;
                        final t = lyrics[i].text.isEmpty ? '♪' : lyrics[i].text;
                        return Center(
                          child: Text(
                            t,
                            textAlign: TextAlign.center,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontSize: active ? 24 : 18,
                              fontWeight: active ? FontWeight.bold : FontWeight.normal,
                              color: active ? JColors.gold : Colors.white54,
                            ),
                          ),
                        );
                      },
                    ),
            ),
            Container(
              color: JColors.panel,
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    children: [
                      Text(_fmt(pos)),
                      Expanded(
                        child: Slider(
                          value: posMs,
                          min: 0,
                          max: maxMs,
                          onChanged: (v) =>
                              player.seek(Duration(milliseconds: v.round())),
                        ),
                      ),
                      Text(_fmt(dur)),
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      IconButton(
                        iconSize: 44,
                        color: JColors.blue,
                        icon: Icon(playing ? Icons.pause_circle : Icons.play_circle),
                        onPressed: recording
                            ? null
                            : () => playing ? player.pause() : player.play(),
                      ),
                      const SizedBox(width: 12),
                      if (hasInst) ...[
                        ChoiceChip(
                          label: const Text('Original'),
                          selected: !useInstrumental,
                          onSelected: recording ? null : (_) => _switchSource(false),
                        ),
                        const SizedBox(width: 8),
                        ChoiceChip(
                          label: const Text('Sin voz'),
                          selected: useInstrumental,
                          onSelected: recording ? null : (_) => _switchSource(true),
                        ),
                      ] else
                        TextButton.icon(
                          onPressed: recording
                              ? null
                              : () async {
                                  final ok = await separateWithDialog(context, widget.song);
                                  if (ok && mounted) await _switchSource(true);
                                },
                          icon: const Icon(Icons.auto_awesome),
                          label: const Text('Quitar voz (IA)'),
                        ),
                    ],
                  ),
                  _slider('Velocidad ${speed.toStringAsFixed(2)}x', speed, 0.5, 1.5, 20,
                      (v) {
                    setState(() => speed = v);
                    player.setSpeed(v);
                  }),
                  _slider('Tono ${semis > 0 ? '+' : ''}${semis.round()}', semis, -6, 6, 12,
                      (v) {
                    setState(() => semis = v);
                    player.setPitch(math.pow(2, v / 12).toDouble());
                  }),
                  _slider('Volumen música', volume, 0, 1, 20, (v) {
                    setState(() => volume = v);
                    player.setVolume(v);
                  }),
                  const SizedBox(height: 6),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      style: FilledButton.styleFrom(
                        backgroundColor: recording ? Colors.red : JColors.gold,
                        foregroundColor: recording ? Colors.white : Colors.black,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                      ),
                      onPressed: recording ? _stopRecording : _startRecording,
                      icon: Icon(recording ? Icons.stop : Icons.mic),
                      label: Text(recording ? 'DETENER Y REVISAR' : 'CANTAR Y GRABAR'),
                    ),
                  ),
                  const Padding(
                    padding: EdgeInsets.only(top: 4),
                    child: Text('Usa audífonos al grabar.',
                        style: TextStyle(fontSize: 12, color: Colors.white54)),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _slider(String label, double v, double min, double max, int div,
      ValueChanged<double> onChanged) {
    return Row(
      children: [
        SizedBox(width: 120, child: Text(label, style: const TextStyle(fontSize: 13))),
        Expanded(
          child: Slider(value: v, min: min, max: max, divisions: div, onChanged: onChanged),
        ),
      ],
    );
  }
}
