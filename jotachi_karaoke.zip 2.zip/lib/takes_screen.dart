import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:share_plus/share_plus.dart';
import 'api.dart';
import 'models.dart';
import 'theme.dart';

class TakesTab extends StatelessWidget {
  const TakesTab({super.key});

  String _date(DateTime d) =>
      '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Mis grabaciones')),
      body: ListenableBuilder(
        listenable: Library.I,
        builder: (context, _) {
          final takes = Library.I.takes;
          if (takes.isEmpty) {
            return const Center(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: Text(
                  'Aún no tienes grabaciones.\nElige una canción y toca "Cantar y grabar".',
                  textAlign: TextAlign.center,
                ),
              ),
            );
          }
          return ListView.builder(
            itemCount: takes.length,
            itemBuilder: (_, i) {
              final t = takes[i];
              return ListTile(
                leading: const Icon(Icons.mic, color: JColors.gold),
                title: Text(t.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                subtitle: Text(_date(t.createdAt) +
                    (t.mixedPath != null ? ' · Mezcla lista' : '')),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => TakeScreen(take: t)),
                ),
              );
            },
          );
        },
      ),
    );
  }
}

class TakeScreen extends StatefulWidget {
  final Take take;
  const TakeScreen({super.key, required this.take});

  @override
  State<TakeScreen> createState() => _TakeScreenState();
}

class _TakeScreenState extends State<TakeScreen> {
  final vp = AudioPlayer();
  final mp = AudioPlayer();
  bool playing = false;
  bool busy = false;
  bool ready = false;
  StreamSubscription<PlayerState>? sub;

  Take get t => widget.take;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    try {
      await vp.setFilePath(t.voicePath);
      await mp.setFilePath(t.musicPath);
      await mp.setSpeed(t.speed);
      await mp.setPitch(math.pow(2, t.semitones / 12).toDouble());
      await vp.setVolume(math.min(t.voiceVol, 1.0));
      await mp.setVolume(t.musicVol);
      sub = vp.playerStateStream.listen((st) async {
        if (st.processingState == ProcessingState.completed) {
          await mp.pause();
          if (mounted) setState(() => playing = false);
        }
      });
      if (mounted) setState(() => ready = true);
    } catch (e) {
      _msg('No se pudo abrir la grabación: $e');
    }
  }

  void _msg(String s) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s)));
  }

  Future<void> _toggle() async {
    if (playing) {
      await vp.pause();
      await mp.pause();
      setState(() => playing = false);
      return;
    }
    await Future.wait([vp.seek(Duration.zero), mp.seek(Duration.zero)]);
    unawaited(vp.play());
    unawaited(mp.play());
    setState(() => playing = true);
  }

  Future<void> _export() async {
    setState(() => busy = true);
    try {
      final path = await Api.mix(t);
      await Share.shareXFiles([XFile(path)], text: 'Mi interpretación en JOTACHI KARAOKE');
    } catch (e) {
      _msg('No se pudo exportar: $e');
    }
    if (mounted) setState(() => busy = false);
  }

  Future<void> _share() async {
    final path = t.mixedPath;
    if (path == null) return;
    await Share.shareXFiles([XFile(path)], text: 'Mi interpretación en JOTACHI KARAOKE');
  }

  Future<void> _delete() async {
    await vp.pause();
    await mp.pause();
    await Library.I.removeTake(t);
    if (mounted) Navigator.pop(context);
  }

  @override
  void dispose() {
    sub?.cancel();
    vp.dispose();
    mp.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(t.title, overflow: TextOverflow.ellipsis),
        actions: [
          IconButton(icon: const Icon(Icons.delete_outline), onPressed: _delete),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Center(
            child: IconButton(
              iconSize: 80,
              color: JColors.blue,
              icon: Icon(playing ? Icons.pause_circle : Icons.play_circle),
              onPressed: ready ? _toggle : null,
            ),
          ),
          const SizedBox(height: 8),
          const Text('Mezclador', style: TextStyle(fontSize: 16, color: JColors.gold)),
          Row(children: [
            const SizedBox(width: 100, child: Text('Micrófono')),
            Expanded(
              child: Slider(
                value: t.voiceVol,
                min: 0,
                max: 1.5,
                onChanged: (v) {
                  setState(() => t.voiceVol = v);
                  vp.setVolume(math.min(v, 1.0));
                },
                onChangeEnd: (_) => Library.I.update(),
              ),
            ),
          ]),
          Row(children: [
            const SizedBox(width: 100, child: Text('Música')),
            Expanded(
              child: Slider(
                value: t.musicVol,
                min: 0,
                max: 1,
                onChanged: (v) {
                  setState(() => t.musicVol = v);
                  mp.setVolume(v);
                },
                onChangeEnd: (_) => Library.I.update(),
              ),
            ),
          ]),
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: busy ? null : _export,
            icon: const Icon(Icons.auto_awesome),
            label: const Text('Exportar mezcla en un solo archivo (servidor IA)'),
          ),
          if (t.mixedPath != null) ...[
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: _share,
              icon: const Icon(Icons.share),
              label: const Text('Compartir mezcla'),
            ),
          ],
          if (busy)
            const Padding(
              padding: EdgeInsets.only(top: 16),
              child: Center(child: CircularProgressIndicator()),
            ),
        ],
      ),
    );
  }
}
