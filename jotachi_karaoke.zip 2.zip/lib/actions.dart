import 'package:flutter/material.dart';
import 'api.dart';
import 'models.dart';

/// Separa la voz con IA mostrando una ventana de progreso.
/// Devuelve true si terminó bien.
Future<bool> separateWithDialog(BuildContext context, Song s) async {
  final msg = ValueNotifier<String>('Preparando...');
  showDialog<void>(
    context: context,
    barrierDismissible: false,
    builder: (_) => AlertDialog(
      title: const Text('Separando voz con IA'),
      content: ValueListenableBuilder<String>(
        valueListenable: msg,
        builder: (_, v, __) => Row(
          children: [
            const SizedBox(
                width: 24,
                height: 24,
                child: CircularProgressIndicator(strokeWidth: 2)),
            const SizedBox(width: 16),
            Expanded(child: Text(v)),
          ],
        ),
      ),
    ),
  );
  var ok = true;
  var result = 'Listo. Ya puedes cantar sobre la versión sin voz.';
  try {
    await Api.separate(s, (m) => msg.value = m);
  } catch (e) {
    ok = false;
    result = 'No se pudo separar: $e';
  }
  if (context.mounted) {
    Navigator.of(context).pop();
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(result)));
  }
  return ok;
}
