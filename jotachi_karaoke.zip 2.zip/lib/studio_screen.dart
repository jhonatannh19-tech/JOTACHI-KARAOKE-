import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:path_provider/path_provider.dart';
import 'fx.dart';
import 'models.dart';
import 'theme.dart';

/// Después de cantar: efectos de estudio, mezclador y guardado.
class StudioScreen extends StatefulWidget {
  final Song song;
  final String rawPath;
  final String musicPath;
  final double speed;
  final double semitones;

  const StudioScreen({
    super.key,
    required this.song,
    required this.rawPath,
    required this.musicPath,
    required this.speed,
    required this.semitones,
  });

  @override
  State<StudioScreen> createState() => _StudioScreenState();
}

class _StudioScreenState extends State<StudioScreen> {
  final vp = AudioPlayer();
  final mp = AudioPlayer();
  late String voicePath;
  FxParams fx = FxParams.presets['Estudio']!;
  String preset = 'Estudio';
  double voiceVol = 1;
  double musicVol = 0.8;
  bool busy = false;
  bool playing = false;
  bool ready = false;
  StreamSubscription<PlayerState>? sub;

  @override
  void initState() {
    super.initState();
    voicePath = widget.rawPath;
    _init();
  }

  Future<void> _init() async {
    try {
      await vp.setFilePath(voicePath);
      await mp.setFilePath(widget.musicPath);
      await mp.setSpeed(widget.speed);
      await mp.setPitch(math.pow(2, widget.semitones / 12).toDouble());
      await vp.setVolume(voiceVol);
      await mp.setVolume(musicVol);
      sub = vp.playerStateStream.listen((st) async {
        if (st.processingState == ProcessingState.completed) {
          await mp.pause();
          if (mounted) setState(() => playing = false);
        }
      });
      if (mounted) setState(() => ready = true);
    } catch (e) {
      _msg('No se pudo preparar la revisión: $e');
    }
  }

  void _msg(String t) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t)));
  }

  Future<void> _stopPreview() async {
    await vp.pause();
    await mp.pause();
    if (mounted) setState(() => playing = false);
  }

  Future<void> _toggle() async {
    if (playing) {
      await _stopPreview();
      return;
    }
    await Future.wait([vp.seek(Duration.zero), mp.seek(Duration.zero)]);
    unawaited(vp.play());
    unawaited(mp.play());
    setState(() => playing = true);
  }

  Future<void> _apply() async {
    setState(() => busy = true);
    await _stopPreview();
    try {
      final tmp = await getTemporaryDirectory();
      final out = '${tmp.path}/fx_${DateTime.now().millisecondsSinceEpoch}.wav';
      await applyEffects(widget.rawPath, out, fx);
      voicePath = out;
      await vp.setFilePath(out);
      await vp.setVolume(voiceVol);
      _msg('Efectos aplicados. Toca reproducir para escucharlos.');
    } catch (e) {
      _msg('No se pudieron aplicar los efectos: $e');
    }
    if (mounted) setState(() => busy = false);
  }

  Future<void> _save() async {
    setState(() => busy = true);
    await _stopPreview();
    try {
      final dir = await Library.I.folder('takes');
      final id = DateTime.now().microsecondsSinceEpoch.toString();
      final dest = '$dir/$id.wav';
      await File(voicePath).copy(dest);
      final t = Take(
        id: id,
        title: widget.song.title,
        voicePath: dest,
        musicPath: widget.musicPath,
        voiceVol: voiceVol,
        musicVol: musicVol,
        speed: widget.speed,
        semitones: widget.semitones,
        createdAt: DateTime.now(),
      );
      await Library.I.addTake(t);
      if (!mounted) return;
      Navigator.popUntil(context, (r) => r.isFirst);
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Interpretación guardada en Grabaciones.')));
    } catch (e) {
      _msg('No se pudo guardar: $e');
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  void dispose() {
    sub?.cancel();
    vp.dispose();
    mp.dispose();
    super.dispose();
  }

  Widget _slider(String label, double v, double min, double max,
      ValueChanged<double> onChanged) {
    return Row(
      children: [
        SizedBox(width: 120, child: Text(label, style: const TextStyle(fontSize: 13))),
        Expanded(child: Slider(value: v, min: min, max: max, onChanged: onChanged)),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Estudio')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Text(widget.song.title,
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            const Text('Efectos de voz',
                style: TextStyle(fontSize: 16, color: JColors.gold)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              children: [
                for (final e in FxParams.presets.entries)
                  ChoiceChip(
                    label: Text(e.key),
                    selected: preset == e.key,
                    onSelected: busy
                        ? null
                        : (_) => setState(() {
                              preset = e.key;
                              fx = e.value;
                            }),
                  ),
              ],
            ),
            _slider('Eco', fx.echoMix, 0, 0.8,
                (v) => setState(() => fx = fx.copyWith(echoMix: v))),
            _slider('Tiempo del eco', fx.echoDelayMs, 60, 600,
                (v) => setState(() => fx = fx.copyWith(echoDelayMs: v))),
            _slider('Reverberación', fx.reverbMix, 0, 1,
                (v) => setState(() => fx = fx.copyWith(reverbMix: v))),
            _slider('Tamaño de sala', fx.reverbSize, 0, 1,
                (v) => setState(() => fx = fx.copyWith(reverbSize: v))),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: (busy || !ready) ? null : _apply,
              icon: const Icon(Icons.graphic_eq),
              label: const Text('Aplicar efectos'),
            ),
            const SizedBox(height: 20),
            const Text('Mezclador',
                style: TextStyle(fontSize: 16, color: JColors.gold)),
            _slider('Micrófono', voiceVol, 0, 1.5, (v) {
              setState(() => voiceVol = v);
              vp.setVolume(math.min(v, 1.0));
            }),
            _slider('Música', musicVol, 0, 1, (v) {
              setState(() => musicVol = v);
              mp.setVolume(v);
            }),
            const SizedBox(height: 12),
            FilledButton.icon(
              style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 14)),
              onPressed: (busy || !ready) ? null : _toggle,
              icon: Icon(playing ? Icons.stop : Icons.play_arrow),
              label: Text(playing ? 'Detener' : 'Escuchar mi interpretación'),
            ),
            const SizedBox(height: 10),
            FilledButton.icon(
              style: FilledButton.styleFrom(
                backgroundColor: JColors.gold,
                foregroundColor: Colors.black,
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
              onPressed: busy ? null : _save,
              icon: const Icon(Icons.save),
              label: const Text('Guardar interpretación'),
            ),
            if (busy)
              const Padding(
                padding: EdgeInsets.only(top: 16),
                child: Center(child: CircularProgressIndicator()),
              ),
          ],
        ),
      ),
    );
  }
}
