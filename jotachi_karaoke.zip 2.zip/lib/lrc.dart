import 'dart:convert';
import 'dart:io';

class LrcLine {
  final Duration time;
  final String text;
  LrcLine(this.time, this.text);
}

List<LrcLine> parseLrc(String src) {
  final out = <LrcLine>[];
  final tag = RegExp(r'\[(\d{1,3}):(\d{1,2})(?:[.:](\d{1,3}))?\]');
  for (final raw in src.split(RegExp(r'\r?\n'))) {
    final ms = tag.allMatches(raw).toList();
    if (ms.isEmpty) continue;
    final text = raw.replaceAll(tag, '').trim();
    for (final m in ms) {
      final min = int.parse(m.group(1)!);
      final sec = int.parse(m.group(2)!);
      final fr = m.group(3);
      var millis = 0;
      if (fr != null) {
        if (fr.length == 1) {
          millis = int.parse(fr) * 100;
        } else if (fr.length == 2) {
          millis = int.parse(fr) * 10;
        } else {
          millis = int.parse(fr);
        }
      }
      out.add(LrcLine(
          Duration(minutes: min, seconds: sec, milliseconds: millis), text));
    }
  }
  out.sort((a, b) => a.time.compareTo(b.time));
  return out;
}

Future<List<LrcLine>> loadLrc(String? path) async {
  if (path == null) return [];
  final f = File(path);
  if (!await f.exists()) return [];
  final bytes = await f.readAsBytes();
  return parseLrc(utf8.decode(bytes, allowMalformed: true));
}
