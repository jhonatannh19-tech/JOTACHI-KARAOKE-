import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'package:flutter/foundation.dart';

/// Parámetros de los efectos de voz.
class FxParams {
  final double echoMix; // 0..1
  final double echoDelayMs; // 60..600
  final double echoFeedback; // 0..0.7
  final double reverbMix; // 0..1
  final double reverbSize; // 0..1

  const FxParams({
    this.echoMix = 0,
    this.echoDelayMs = 280,
    this.echoFeedback = 0.35,
    this.reverbMix = 0,
    this.reverbSize = 0.5,
  });

  FxParams copyWith({
    double? echoMix,
    double? echoDelayMs,
    double? echoFeedback,
    double? reverbMix,
    double? reverbSize,
  }) =>
      FxParams(
        echoMix: echoMix ?? this.echoMix,
        echoDelayMs: echoDelayMs ?? this.echoDelayMs,
        echoFeedback: echoFeedback ?? this.echoFeedback,
        reverbMix: reverbMix ?? this.reverbMix,
        reverbSize: reverbSize ?? this.reverbSize,
      );

  List<double> toList() =>
      [echoMix, echoDelayMs, echoFeedback, reverbMix, reverbSize];

  static const Map<String, FxParams> presets = {
    'Seco': FxParams(),
    'Estudio': FxParams(
        echoMix: 0.12,
        echoDelayMs: 120,
        echoFeedback: 0.2,
        reverbMix: 0.25,
        reverbSize: 0.35),
    'Escenario': FxParams(
        echoMix: 0.3,
        echoDelayMs: 300,
        echoFeedback: 0.35,
        reverbMix: 0.4,
        reverbSize: 0.6),
    'Catedral': FxParams(
        echoMix: 0.2,
        echoDelayMs: 420,
        echoFeedback: 0.45,
        reverbMix: 0.7,
        reverbSize: 1.0),
  };
}

/// Aplica eco y reverberación a un WAV de 16 bits y guarda el resultado.
Future<void> applyEffects(String input, String output, FxParams p) async {
  await compute(_process, <dynamic>[input, output, p.toList()]);
}

bool _process(List<dynamic> args) {
  final inPath = args[0] as String;
  final outPath = args[1] as String;
  final prm = (args[2] as List).map((e) => (e as num).toDouble()).toList();

  final bytes = File(inPath).readAsBytesSync();
  final bd = ByteData.sublistView(bytes);
  final channels = bd.getUint16(22, Endian.little);
  final rate = bd.getUint32(24, Endian.little);
  final bits = bd.getUint16(34, Endian.little);
  if (bits != 16 || channels < 1) {
    throw Exception('Se necesita un WAV de 16 bits');
  }

  var pos = 12;
  var dataStart = -1;
  var dataLen = 0;
  while (pos + 8 <= bytes.length) {
    final id = String.fromCharCodes(bytes.sublist(pos, pos + 4));
    final size = bd.getUint32(pos + 4, Endian.little);
    if (id == 'data') {
      dataStart = pos + 8;
      dataLen = size;
      break;
    }
    pos += 8 + size + (size & 1);
  }
  if (dataStart < 0) throw Exception('WAV sin datos');
  final remaining = bytes.length - dataStart;
  if (dataLen == 0 || dataLen > remaining) dataLen = remaining;

  final frames = dataLen ~/ (2 * channels);
  final tail = rate * 3; // 3 s extra para que la cola se apague sola
  final total = frames + tail;

  final chans = List<Float32List>.generate(channels, (_) => Float32List(total));
  for (var f = 0; f < frames; f++) {
    for (var c = 0; c < channels; c++) {
      chans[c][f] =
          bd.getInt16(dataStart + (f * channels + c) * 2, Endian.little) /
              32768.0;
    }
  }

  for (final x in chans) {
    _fx(x, rate, prm);
  }

  var peak = 0.0;
  for (final x in chans) {
    for (var i = 0; i < total; i++) {
      final a = x[i].abs();
      if (a > peak) peak = a;
    }
  }
  final gain = peak > 0.97 ? 0.97 / peak : 1.0;

  final out = ByteData(44 + total * channels * 2);
  void tag(int off, String s) {
    for (var i = 0; i < 4; i++) {
      out.setUint8(off + i, s.codeUnitAt(i));
    }
  }

  tag(0, 'RIFF');
  out.setUint32(4, 36 + total * channels * 2, Endian.little);
  tag(8, 'WAVE');
  tag(12, 'fmt ');
  out.setUint32(16, 16, Endian.little);
  out.setUint16(20, 1, Endian.little);
  out.setUint16(22, channels, Endian.little);
  out.setUint32(24, rate, Endian.little);
  out.setUint32(28, rate * channels * 2, Endian.little);
  out.setUint16(32, channels * 2, Endian.little);
  out.setUint16(34, 16, Endian.little);
  tag(36, 'data');
  out.setUint32(40, total * channels * 2, Endian.little);

  var o = 44;
  for (var f = 0; f < total; f++) {
    for (var c = 0; c < channels; c++) {
      final v = (chans[c][f] * gain * 32767).round().clamp(-32768, 32767).toInt();
      out.setInt16(o, v, Endian.little);
      o += 2;
    }
  }
  File(outPath).writeAsBytesSync(out.buffer.asUint8List());
  return true;
}

void _fx(Float32List x, int rate, List<double> p) {
  final n = x.length;
  final echoMix = p[0];
  final dly = math.max(1, (p[1] * rate / 1000).round());
  final fb = p[2];
  final rvMix = p[3];
  final size = p[4];

  // ECO
  if (echoMix > 0) {
    final dry = Float32List.fromList(x);
    final w = Float32List(n);
    for (var i = 0; i < n; i++) {
      final prev = i >= dly ? w[i - dly] : 0.0;
      w[i] = dry[i] + fb * prev;
      if (i >= dly) x[i] += echoMix * w[i - dly];
    }
  }

  // REVERB (Schroeder: 4 combs en paralelo + 2 allpass en serie)
  if (rvMix > 0) {
    final scale = rate / 44100.0 * (0.6 + 0.8 * size);
    final combLens =
        [1116, 1188, 1277, 1356].map((v) => (v * scale).round()).toList();
    final apLens = [556, 441].map((v) => (v * scale).round()).toList();
    final fbk = 0.72 + 0.2 * size;
    const damp = 0.25;

    final combBufs = combLens.map((l) => Float32List(l)).toList();
    final combIdx = List<int>.filled(4, 0);
    final combFilt = List<double>.filled(4, 0.0);
    final apBufs = apLens.map((l) => Float32List(l)).toList();
    final apIdx = List<int>.filled(2, 0);
    final input = Float32List.fromList(x);

    for (var i = 0; i < n; i++) {
      final s = input[i] * 0.15;
      var acc = 0.0;
      for (var k = 0; k < 4; k++) {
        final b = combBufs[k];
        final ix = combIdx[k];
        final y = b[ix];
        combFilt[k] = y * (1 - damp) + combFilt[k] * damp;
        b[ix] = s + combFilt[k] * fbk;
        combIdx[k] = (ix + 1 == b.length) ? 0 : ix + 1;
        acc += y;
      }
      for (var k = 0; k < 2; k++) {
        final b = apBufs[k];
        final ix = apIdx[k];
        final bo = b[ix];
        final o = -acc + bo;
        b[ix] = acc + bo * 0.5;
        apIdx[k] = (ix + 1 == b.length) ? 0 : ix + 1;
        acc = o;
      }
      x[i] += rvMix * acc * 1.5;
    }
  }
}
