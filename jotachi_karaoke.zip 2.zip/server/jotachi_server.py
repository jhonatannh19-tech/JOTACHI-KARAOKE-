"""Servidor de IA para JOTACHI KARAOKE (separación de voz y mezcla final).
Pensado para Google Colab con GPU. Endpoints:
  GET  /health
  POST /separate        (file)               -> {"job": id}
  GET  /status/{job}                         -> {"state": running|done|error, "message": ...}
  GET  /stem/{job}/{name}   name: vocals|instrumental|drums|bass|other
  POST /mix  (voice, music, voice_vol, music_vol, speed, semitones) -> mp3
"""
import glob
import os
import subprocess
import threading
import uuid

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse

WORK = "/content/jotachi_work" if os.path.isdir("/content") else os.path.abspath("work")
os.makedirs(WORK, exist_ok=True)

app = FastAPI()
JOBS = {}


@app.get("/health")
def health():
    return {"ok": True}


def _run_separation(job: str, src: str):
    try:
        out = os.path.join(WORK, job, "out")
        JOBS[job] = {"state": "running", "message": "Separando con IA (puede tardar unos minutos)..."}
        subprocess.run(
            ["python", "-m", "demucs", "-n", "htdemucs", "--mp3", "--mp3-bitrate", "192", "-o", out, src],
            check=True, capture_output=True,
        )
        stem_dir = glob.glob(os.path.join(out, "htdemucs", "*"))[0]
        JOBS[job] = {"state": "running", "message": "Preparando la versión sin voz..."}
        subprocess.run(
            ["ffmpeg", "-y",
             "-i", os.path.join(stem_dir, "drums.mp3"),
             "-i", os.path.join(stem_dir, "bass.mp3"),
             "-i", os.path.join(stem_dir, "other.mp3"),
             "-filter_complex", "amix=inputs=3:duration=longest:normalize=0",
             "-b:a", "192k", os.path.join(stem_dir, "instrumental.mp3")],
            check=True, capture_output=True,
        )
        JOBS[job] = {"state": "done", "message": "Listo", "dir": stem_dir}
    except Exception as e:  # noqa: BLE001
        JOBS[job] = {"state": "error", "message": "Falló la separación: %s" % e}


@app.post("/separate")
async def separate(file: UploadFile = File(...)):
    job = uuid.uuid4().hex[:12]
    folder = os.path.join(WORK, job)
    os.makedirs(folder, exist_ok=True)
    ext = os.path.splitext(file.filename or "")[1] or ".mp3"
    src = os.path.join(folder, "input" + ext)
    with open(src, "wb") as f:
        f.write(await file.read())
    JOBS[job] = {"state": "running", "message": "En cola..."}
    threading.Thread(target=_run_separation, args=(job, src), daemon=True).start()
    return {"job": job}


@app.get("/status/{job}")
def status(job: str):
    if job not in JOBS:
        raise HTTPException(404, "Trabajo no encontrado")
    j = JOBS[job]
    return {"state": j["state"], "message": j["message"]}


@app.get("/stem/{job}/{name}")
def stem(job: str, name: str):
    if name not in ("vocals", "instrumental", "drums", "bass", "other"):
        raise HTTPException(400, "Nombre no válido")
    j = JOBS.get(job)
    if not j or j.get("state") != "done":
        raise HTTPException(404, "Aún no está listo")
    path = os.path.join(j["dir"], name + ".mp3")
    if not os.path.exists(path):
        raise HTTPException(404, "No existe")
    return FileResponse(path, media_type="audio/mpeg")


def _clamp_tempo(x: float) -> float:
    return max(0.5, min(2.0, x))


@app.post("/mix")
async def mix(
    voice: UploadFile = File(...),
    music: UploadFile = File(...),
    voice_vol: float = Form(1.0),
    music_vol: float = Form(0.8),
    speed: float = Form(1.0),
    semitones: float = Form(0.0),
):
    job = uuid.uuid4().hex[:12]
    folder = os.path.join(WORK, "mix_" + job)
    os.makedirs(folder, exist_ok=True)
    vpath = os.path.join(folder, "voice" + (os.path.splitext(voice.filename or "")[1] or ".wav"))
    mpath = os.path.join(folder, "music" + (os.path.splitext(music.filename or "")[1] or ".mp3"))
    with open(vpath, "wb") as f:
        f.write(await voice.read())
    with open(mpath, "wb") as f:
        f.write(await music.read())
    r = 2 ** (semitones / 12.0)
    tempo = _clamp_tempo(speed / r)
    flt = (
        "[0:a]aresample=44100,asetrate=%d,aresample=44100,atempo=%.4f,volume=%.3f[m];"
        "[1:a]aresample=44100,volume=%.3f[v];"
        "[m][v]amix=inputs=2:duration=longest:normalize=0[o]"
    ) % (int(44100 * r), tempo, music_vol, voice_vol)
    out = os.path.join(folder, "mix.mp3")
    try:
        subprocess.run(
            ["ffmpeg", "-y", "-i", mpath, "-i", vpath, "-filter_complex", flt,
             "-map", "[o]", "-b:a", "192k", out],
            check=True, capture_output=True,
        )
    except subprocess.CalledProcessError as e:
        raise HTTPException(500, "ffmpeg falló: %s" % e.stderr.decode("utf-8", "ignore")[-300:])
    return FileResponse(out, media_type="audio/mpeg", filename="mezcla.mp3")
